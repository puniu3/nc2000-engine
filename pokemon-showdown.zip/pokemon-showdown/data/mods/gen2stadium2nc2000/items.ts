export const Items: import('../../../sim/dex-items').ModdedItemDataTable = {
  mintberry: {
    inherit: true,
    onUpdate: undefined,
    onBeforeMovePriority: 11,
    onBeforeMove(pokemon) {
      if (pokemon.status === 'slp') {
        pokemon.eatItem();
      }
    },
    onResidualOrder: 5,
    onResidualSubOrder: 1,
    onResidual(pokemon) {
      if (pokemon.status === 'slp') {
        pokemon.eatItem();
      }
    },
  },
  miracleberry: {
    inherit: true,
    onUpdate: undefined,
    onBeforeMovePriority: 11,
    onBeforeMove(pokemon) {
      if (
        pokemon.status ||
	pokemon.volatiles['confusion']
      ) {
        pokemon.eatItem();
      }
    },
    onResidualOrder: 5,
    onResidualSubOrder: 1,
    onResidual(pokemon) {
      if (
        pokemon.status ||
	pokemon.volatiles['confusion']
      ) {
        pokemon.eatItem();
      }
    },
  },
};
