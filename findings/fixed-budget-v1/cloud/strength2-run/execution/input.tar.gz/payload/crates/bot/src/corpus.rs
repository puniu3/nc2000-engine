//! Corpus-position reconstruction shared by the M16b/M17 harnesses:
//! tracker state from the protocol prefix, full-log evidence for the acting
//! side's own submitted set, remaining-set fabrication from
//! rentals/pool/learnsets, then `ProtocolAgent::on_request` synthesis.

use std::collections::{HashMap, HashSet};

use crate::import::{MonSnapshot, ProtocolAgent, ProtocolTracker};
use crate::preview::{load_meta_pool, MetaPool};
use crate::smmcts::{RmConfig, SelRule};
use nc2000_engine::dex::{toid, Dex, SpeciesId};
use nc2000_engine::state::{Battle, MoveSlot, Status};
use nc2000_engine::validate::{validate_team, Learnsets};

/// Full-log facts about the acting side's own set. These are legitimate in
/// an offline reconstruction: a live bot knows its submitted team even when
/// the spectator prefix has not revealed it yet. Battle state and opponent
/// information still come strictly from the decision prefix.
#[derive(Clone, Debug, Default)]
pub struct SetEvidence {
    moves: HashMap<(usize, String), Vec<String>>,
    items: HashMap<(usize, String), ItemEvent>,
    species_names: HashMap<(usize, String), String>,
}

#[derive(Clone, Debug)]
struct ItemEvent {
    cut: usize,
    item: String,
}

impl SetEvidence {
    fn resolved_name<'a>(&'a self, side: usize, name: &'a str, species: &str) -> &'a str {
        if !name.is_empty() {
            name
        } else {
            self.species_names
                .get(&(side, species.to_string()))
                .map(String::as_str)
                .unwrap_or(name)
        }
    }

    fn moves(&self, side: usize, name: &str, species: &str) -> &[String] {
        let name = self.resolved_name(side, name, species);
        self.moves
            .get(&(side, name.to_string()))
            .map(Vec::as_slice)
            .unwrap_or_default()
    }

    fn item(&self, side: usize, name: &str, species: &str) -> Option<&ItemEvent> {
        let name = self.resolved_name(side, name, species);
        self.items.get(&(side, name.to_string()))
    }

    /// Every (species, revealed moves) pair the full log evidences, for
    /// tools that count usage rather than reconstruct a decision. Note the
    /// quantity: these are moves a mon was *seen using*, so counting them
    /// estimates P(reveals), not the P(carries) a belief prior wants — see
    /// `docs/community-belief-prior-design.md`.
    pub fn revealed_by_species(&self) -> Vec<(&str, &[String])> {
        self.moves
            .iter()
            .map(|((side, name), moves)| {
                let species = self
                    .species_names
                    .get(&(*side, name.clone()))
                    .map(String::as_str)
                    .unwrap_or(name.as_str());
                (species, moves.as_slice())
            })
            .collect()
    }
}

/// One loaded corpus battle: filtered protocol lines, full-log own-set
/// evidence, and the extracted observable decisions.
pub struct CorpusBattle {
    pub lines: Vec<String>,
    pub evidence: SetEvidence,
    pub decisions: Vec<Decision>,
}

/// Sorted .raw.log paths of the spectator corpus.
pub fn corpus_files(dir: &std::path::Path) -> Vec<std::path::PathBuf> {
    let mut files: Vec<std::path::PathBuf> = std::fs::read_dir(dir)
        .unwrap_or_else(|e| panic!("corpus dir {}: {e}", dir.display()))
        .filter_map(|e| e.ok().map(|e| e.path()))
        .filter(|p| p.to_string_lossy().ends_with(".raw.log"))
        .collect();
    files.sort();
    files
}

fn fnv1a64_update(hash: u64, bytes: &[u8]) -> u64 {
    bytes.iter().fold(hash, |hash, &byte| {
        (hash ^ byte as u64).wrapping_mul(0x0000_0100_0000_01b3)
    })
}

fn fingerprint_part(hash: u64, bytes: &[u8]) -> u64 {
    let hash = fnv1a64_update(hash, &(bytes.len() as u64).to_le_bytes());
    fnv1a64_update(hash, bytes)
}

/// Content identity of a sorted corpus file list. Paths outside the corpus
/// are deliberately excluded; basenames and bytes are both bound so moving
/// an intact corpus is harmless while renames, additions, and edits are not.
pub fn corpus_fingerprint(files: &[std::path::PathBuf]) -> String {
    let mut hash = 0xcbf2_9ce4_8422_2325;
    for path in files {
        let name = path.file_name().unwrap_or_default().to_string_lossy();
        let contents = std::fs::read(path)
            .unwrap_or_else(|e| panic!("read corpus file {}: {e}", path.display()));
        hash = fingerprint_part(hash, name.as_bytes());
        hash = fingerprint_part(hash, &contents);
    }
    format!("fnv1a64:{hash:016x}:{}files", files.len())
}

/// Fingerprint of the code that maps a corpus prefix plus own-set evidence
/// into a battle. Embedding the relevant sources makes importer/fabricator
/// changes invalidate old proof artifacts automatically, even when their
/// coarse HP/alive diagnostics happen to remain unchanged.
pub fn reconstruction_schema_fingerprint() -> String {
    let sources: [(&str, &[u8]); 2] = [
        ("corpus.rs", include_bytes!("corpus.rs").as_slice()),
        ("import.rs", include_bytes!("import.rs").as_slice()),
    ];
    let mut hash = 0xcbf2_9ce4_8422_2325;
    for (name, contents) in sources {
        hash = fingerprint_part(hash, name.as_bytes());
        hash = fingerprint_part(hash, contents);
    }
    format!("fnv1a64:{hash:016x}:corpus-reconstruction-v1")
}

pub fn load_battle(path: &std::path::Path) -> CorpusBattle {
    let text = std::fs::read_to_string(path).unwrap_or_default();
    let lines: Vec<String> = text
        .lines()
        .filter(|l| {
            let t = l.split('|').nth(1).unwrap_or("");
            !matches!(t, "j" | "l" | "t:" | "init" | "title" | "")
        })
        .map(String::from)
        .collect();
    let decisions = extract_decisions(&lines);
    let evidence = collect_set_evidence(&lines);
    CorpusBattle {
        lines,
        evidence,
        decisions,
    }
}

fn collect_set_evidence(lines: &[String]) -> SetEvidence {
    let mut evidence = SetEvidence::default();
    let mut active_names: [Option<String>; 2] = std::array::from_fn(|_| None);
    let mut transformed: HashSet<(usize, String)> = HashSet::new();
    // A called two-turn move is announced with `[from] Caller` only on its
    // charge turn.  The release is a plain `|move|` line, so remember the
    // authoritative `|-prepare|` that follows the called announcement.
    let mut previous_called: Option<(usize, String, String)> = None;
    let mut called_charging: HashMap<(usize, String), String> = HashMap::new();
    for (cut, line) in lines.iter().enumerate() {
        let parts: Vec<&str> = line.split('|').collect();
        let command = parts.get(1).copied().unwrap_or("");
        let Some(subject) = parts.get(2) else {
            previous_called = None;
            continue;
        };
        let side = if subject.as_bytes().get(1) == Some(&b'2') {
            1
        } else {
            0
        };
        let name = subject.split(':').nth(1).unwrap_or("").trim();
        if name.is_empty() {
            previous_called = None;
            continue;
        }
        if command == "-prepare" {
            let prepared = parts
                .get(3)
                .map(|move_name| plain(&toid(move_name)))
                .unwrap_or_default();
            if previous_called
                .take()
                .is_some_and(|(s, n, key)| s == side && n == name && key == prepared)
            {
                called_charging.insert((side, name.to_string()), prepared);
            }
        } else {
            previous_called = None;
        }
        match command {
            "switch" | "drag" | "replace" => {
                if let Some(outgoing) = active_names[side].replace(name.to_string()) {
                    transformed.remove(&(side, outgoing.clone()));
                    called_charging.remove(&(side, outgoing));
                }
                // A transformed mon returns to its base set on re-entry.
                // `replace` is the protocol's identity-replacement analogue
                // of a switch and likewise must not retain copied moves.
                transformed.remove(&(side, name.to_string()));
                called_charging.remove(&(side, name.to_string()));
                let species = parts
                    .get(3)
                    .map(|details| toid(details.split(',').next().unwrap_or("")))
                    .unwrap_or_default();
                if !species.is_empty() {
                    evidence
                        .species_names
                        .entry((side, species))
                        .or_insert_with(|| name.to_string());
                }
            }
            "-transform" => {
                transformed.insert((side, name.to_string()));
            }
            "-end"
                if parts
                    .get(3)
                    .is_some_and(|effect| toid(effect) == "transform") =>
            {
                transformed.remove(&(side, name.to_string()));
            }
            "faint" => {
                transformed.remove(&(side, name.to_string()));
                called_charging.remove(&(side, name.to_string()));
                if active_names[side].as_deref() == Some(name) {
                    active_names[side] = None;
                }
            }
            "cant" | "-anim" => {
                called_charging.remove(&(side, name.to_string()));
            }
            "move" => {
                // A move executed through Transform belongs to the copied
                // set, not the submitted one.
                if transformed.contains(&(side, name.to_string())) {
                    continue;
                }
                let Some(move_name) = parts.get(3) else {
                    continue;
                };
                let key = plain(&toid(move_name));
                // These are engine-selected actions, never submitted slots.
                if matches!(key.as_str(), "struggle" | "recharge") {
                    continue;
                }
                // `[from] <other move>` is a called move. Sleep Talk is the
                // deliberate exception: its result is one of the submitted
                // slots. `[from] Pursuit` names the executing move itself,
                // so it is an ordinary submitted-move reveal.
                let from_key = parts
                    .iter()
                    .find_map(|part| part.strip_prefix("[from] "))
                    .map(|from| plain(&toid(from.strip_prefix("move: ").unwrap_or(from))));
                if let Some(from) = from_key {
                    if from != key && from != "sleeptalk" {
                        if line.contains("[still]") {
                            previous_called = Some((side, name.to_string(), key));
                        }
                        continue;
                    }
                } else if called_charging
                    .get(&(side, name.to_string()))
                    .is_some_and(|called| *called == key)
                {
                    called_charging.remove(&(side, name.to_string()));
                    continue;
                }
                let moves = evidence.moves.entry((side, name.to_string())).or_default();
                if !moves.contains(&key) {
                    moves.push(key);
                }
            }
            "-enditem" if line.contains("[eat]") => {
                let Some(item) = parts.get(3) else { continue };
                evidence
                    .items
                    .entry((side, name.to_string()))
                    .or_insert(ItemEvent {
                        cut,
                        item: (*item).to_string(),
                    });
            }
            _ => {}
        }
    }
    evidence
}

pub fn cfg() -> RmConfig {
    RmConfig {
        rule: SelRule::Ucb,
        c: 1.0,
        hp_buckets: 16,
        ..RmConfig::default()
    }
}

pub fn plain(key: &str) -> String {
    if key.starts_with("hiddenpower") {
        "hiddenpower".into()
    } else {
        key.into()
    }
}

// -- fabrication machinery -------------------------------------------------

pub struct SetSources {
    #[allow(dead_code)]
    pub by_species: HashMap<SpeciesId, Vec<serde_json::Value>>,
    pub learnsets: HashMap<String, Vec<String>>,
    pub hp_dvs: HashMap<String, (i64, i64)>,
    /// Teams excluded from the pool, as `file#index label`. Kept so the
    /// drop is reportable: this loader used to lose a whole corpus in
    /// silence, and a filter dropping teams on purpose must not look the
    /// same as a loader losing them by accident.
    pub rejected: Vec<String>,
}

/// The sets of one corpus file's format-legal teams, flattened in file
/// order; rejected teams are appended to `rejected` instead.
///
/// A team the regulation rejects, or one the source published for another
/// rule set, is not evidence about the regulation. The rentals file is an
/// archive of everything the source published — a Little Cup team, a
/// Metronome-rule team, a links page, the author's OHKO variants — and
/// `fabricate_set` copies a candidate's moves and item wholesale, so
/// whatever is in here is imputed onto a real opponent verbatim.
fn accepted_team_sets(
    dex: &Dex,
    ls: &Learnsets,
    file: &str,
    text: &str,
    rejected: &mut Vec<String>,
) -> Vec<serde_json::Value> {
    let db: serde_json::Value =
        serde_json::from_str(text).unwrap_or_else(|e| panic!("{file}: {e}"));
    // Asserted, not `if let`-ed: both corpora are `{meta, teams}` objects,
    // and treating a shape mismatch as "no teams" is how this loader read
    // zero of the rentals' 28 teams without anyone noticing.
    let teams = db["teams"]
        .as_array()
        .unwrap_or_else(|| panic!("{file}: expected a `teams` array"));
    let mut out = Vec::new();
    for (i, t) in teams.iter().enumerate() {
        let label = t["id"]
            .as_str()
            .or_else(|| t["archetype"].as_str())
            .unwrap_or("?");
        let Some(sets) = t["sets"].as_array() else {
            rejected.push(format!("{file}#{i} {label} (no sets)"));
            continue;
        };
        // Legal as a team, but published for a different rule set.
        if crate::belief::names_another_ruleset(t["archetype"].as_str().unwrap_or("")) {
            rejected.push(format!("{file}#{i} {label} (another rule set)"));
            continue;
        }
        let team_json = serde_json::Value::Array(sets.clone()).to_string();
        if validate_team(dex, ls, &team_json)["ok"] == serde_json::Value::Bool(true) {
            out.extend(sets.iter().cloned());
        } else {
            rejected.push(format!("{file}#{i} {label}"));
        }
    }
    out
}

pub fn load_sources(dex: &Dex, root: &std::path::Path) -> SetSources {
    let ls_text = std::fs::read_to_string(root.join("data/learnsets-gen2.json")).unwrap();
    let format_ls = Learnsets::from_json(&ls_text).expect("format learnsets must parse");
    let mut rejected: Vec<String> = Vec::new();
    let mut sets: Vec<serde_json::Value> = Vec::new();
    // Meta pool first, deliberately: `fabricate_set` breaks an overlap tie
    // by source order, so listing the rentals first would re-pick nearly
    // every reconstructed set (measured: 100% of corpus decisions) purely
    // by reordering. Pool-first keeps the shipped precedence — `belief.rs`
    // also takes the pool set and falls back to a rental — so the rentals
    // now change a reconstruction only where they strictly fit the revealed
    // moves better, or where the pool has no set for the species at all.
    for file in [
        "data/meta-pool-v0/meta-pool.json",
        "data/community-rentals-v0/teams.json",
    ] {
        let text = std::fs::read_to_string(root.join(file)).unwrap();
        sets.extend(accepted_team_sets(dex, &format_ls, file, &text, &mut rejected));
    }
    let mut by_species: HashMap<SpeciesId, Vec<serde_json::Value>> = HashMap::new();
    for s in sets {
        if let Some(sp) = s["species"].as_str() {
            if let Some(id) = dex.species.id(&toid(sp)) {
                by_species.entry(id).or_default().push(s);
            }
        }
    }
    let ls: serde_json::Value = serde_json::from_str(&ls_text).unwrap();
    let mut learnsets = HashMap::new();
    if let Some(sp) = ls["species"].as_object() {
        for (k, v) in sp {
            let moves: Vec<String> = v["moves"]
                .as_array()
                .map(|a| {
                    a.iter()
                        .filter_map(|m| m.as_str().map(String::from))
                        .collect()
                })
                .unwrap_or_default();
            learnsets.insert(k.clone(), moves);
        }
    }
    let mut hp_dvs = HashMap::new();
    if let Some(o) = ls["hpDvs"].as_object() {
        for (k, v) in o {
            hp_dvs.insert(
                k.clone(),
                (
                    v["atk"].as_i64().unwrap_or(15),
                    v["def"].as_i64().unwrap_or(15),
                ),
            );
        }
    }
    SetSources {
        by_species,
        learnsets,
        hp_dvs,
        rejected,
    }
}

#[derive(Clone, Debug)]
pub enum HumanAction {
    Move(String),
    Switch(String),
}

#[derive(Clone, Debug)]
pub struct Decision {
    pub side: usize,
    pub turn: u16,
    pub cut: usize,
    pub action: HumanAction,
}

pub fn extract_decisions(lines: &[String]) -> Vec<Decision> {
    let mut out = Vec::new();
    let mut turn_open = false;
    let mut turn = 0u16;
    let mut cut = 0usize;
    let mut fainted = [false; 2];
    let mut decided = [false; 2];
    for (i, ln) in lines.iter().enumerate() {
        let p: Vec<&str> = ln.split('|').collect();
        if p.len() < 2 {
            continue;
        }
        let side_of = |s: &str| -> usize {
            if s.as_bytes().get(1) == Some(&b'2') {
                1
            } else {
                0
            }
        };
        match p[1] {
            "turn" => {
                turn_open = true;
                turn = p[2].parse().unwrap_or(0);
                cut = i;
                fainted = [false; 2];
                decided = [false; 2];
            }
            "faint" => fainted[side_of(p[2])] = true,
            "cant" => {
                let s = side_of(p[2]);
                if turn_open && !decided[s] {
                    decided[s] = true;
                }
            }
            "switch" => {
                let s = side_of(p[2]);
                if turn_open && !decided[s] {
                    if !fainted[s] {
                        let species = p[3].split(',').next().unwrap_or("").trim();
                        out.push(Decision {
                            side: s,
                            turn,
                            cut,
                            action: HumanAction::Switch(toid(species)),
                        });
                    }
                    decided[s] = true;
                }
            }
            "move" => {
                let s = side_of(p[2]);
                let from = ln.contains("[from]");
                if turn_open && !decided[s] && !from {
                    out.push(Decision {
                        side: s,
                        turn,
                        cut,
                        action: HumanAction::Move(plain(&toid(p[3]))),
                    });
                    decided[s] = true;
                }
            }
            _ => {}
        }
    }
    out
}

pub fn fabricate_set(
    dex: &Dex,
    src: &SetSources,
    m: &MonSnapshot,
    future_moves: &[String],
    known_item: Option<&str>,
    item_consumed: bool,
) -> (serde_json::Value, &'static str) {
    let sp_key = dex.species.key(m.species).to_string();
    let sp_name = dex.species.get(m.species).name.clone();
    let mut revealed: Vec<String> = m
        .uses
        .iter()
        .map(|(id, _)| plain(dex.moves.key(*id)))
        .collect();
    for key in future_moves {
        if !revealed.contains(key) {
            revealed.push(key.clone());
        }
    }
    let nick = if m.name.is_empty() {
        sp_name.clone()
    } else {
        m.name.clone()
    };
    let gender = match format!("{:?}", m.gender).as_str() {
        "M" => "M",
        "F" => "F",
        _ => "",
    };

    let cands = src
        .by_species
        .get(&m.species)
        .map(|v| v.as_slice())
        .unwrap_or(&[]);
    let norm_moves = |set: &serde_json::Value| -> Vec<String> {
        set["moves"]
            .as_array()
            .map(|a| {
                a.iter()
                    .filter_map(|x| x.as_str().map(|s| plain(&toid(s))))
                    .collect()
            })
            .unwrap_or_default()
    };
    let mut best: Option<(usize, bool, usize)> = None;
    for (i, c) in cands.iter().enumerate() {
        let cm = norm_moves(c);
        let overlap = revealed.iter().filter(|r| cm.contains(r)).count();
        let full = overlap == revealed.len();
        let better = best.map_or(true, |(o, f, bi)| {
            overlap > o || (overlap == o && (full > f || (full == f && i < bi)))
        });
        if better {
            best = Some((overlap, full, i));
        }
    }

    let mut set;
    let provenance;
    match best {
        Some((_, true, i)) if !revealed.is_empty() || !cands.is_empty() => {
            set = cands[i].clone();
            provenance = "cand-full";
        }
        Some((_, false, i)) => {
            set = cands[i].clone();
            let cm: Vec<String> = set["moves"]
                .as_array()
                .map(|a| {
                    a.iter()
                        .filter_map(|x| x.as_str().map(String::from))
                        .collect()
                })
                .unwrap_or_default();
            let mut moves: Vec<String> = Vec::new();
            for r in &revealed {
                let disp = dex
                    .moves
                    .id(r)
                    .map(|id| dex.moves.get(id).name.clone())
                    .unwrap_or_else(|| r.clone());
                moves.push(disp);
            }
            for c in cm {
                if moves.len() >= 4 {
                    break;
                }
                if !moves.iter().any(|x| plain(&toid(x)) == plain(&toid(&c))) {
                    moves.push(c);
                }
            }
            set["moves"] = serde_json::json!(moves);
            provenance = "cand-fill";
        }
        _ => {
            let legal = src.learnsets.get(&sp_key).cloned().unwrap_or_default();
            let mut moves: Vec<String> = Vec::new();
            let mut ivs = serde_json::json!({});
            for r in &revealed {
                if r == "hiddenpower" {
                    let (a, d) = *src.hp_dvs.get("ice").unwrap_or(&(15, 13));
                    ivs = serde_json::json!({"atk": a * 2, "def": d * 2});
                    moves.push("Hidden Power".into());
                } else if let Some(id) = dex.moves.id(r) {
                    moves.push(dex.moves.get(id).name.clone());
                }
            }
            let mut scored: Vec<(u16, String, String)> = legal
                .iter()
                .filter_map(|k| {
                    let id = dex.moves.id(k)?;
                    let md = dex.moves.get(id);
                    if md.category == "Status" || k.starts_with("hiddenpower") {
                        return None;
                    }
                    Some((md.base_power, md.move_type.clone(), md.name.clone()))
                })
                .collect();
            scored.sort_by(|a, b| b.0.cmp(&a.0));
            let mut seen_types: Vec<String> = Vec::new();
            for (_, ty, name) in scored {
                if moves.len() >= 4 {
                    break;
                }
                if moves.iter().any(|x| plain(&toid(x)) == plain(&toid(&name))) {
                    continue;
                }
                if seen_types.contains(&ty) {
                    continue;
                }
                seen_types.push(ty.clone());
                moves.push(name);
            }
            set = serde_json::json!({
                "species": sp_name, "item": "Leftovers", "ability": "No Ability",
                "moves": moves, "nature": "Serious",
                "evs": {"hp":255,"atk":255,"def":255,"spa":255,"spd":255,"spe":255},
                "ivs": ivs,
            });
            provenance = "learnset-pad";
        }
    }
    set["name"] = serde_json::json!(nick);
    set["level"] = serde_json::json!(m.level);
    set["gender"] = serde_json::json!(gender);
    if let Some(item) = known_item {
        set["item"] = serde_json::json!(item);
    }
    if item_consumed {
        set["item"] = serde_json::json!("");
    }
    (set, provenance)
}

pub fn details(dex: &Dex, m: &MonSnapshot) -> String {
    let name = &dex.species.get(m.species).name;
    let mut d = format!("{}, L{}", name, m.level);
    match format!("{:?}", m.gender).as_str() {
        "M" => d.push_str(", M"),
        "F" => d.push_str(", F"),
        _ => {}
    }
    d
}

// -- position reconstruction (human_agreement's per-decision body through
// on_request; no search step) ---------------------------------------------

/// Reconstruct one public-information decision point and retain the
/// protocol agent's belief/observer alongside the synthesized battle.  The
/// M17a regret miner needs all three to repeat blind searches from exactly
/// the same information set.
pub fn reconstruct_agent(
    dex: &Dex,
    src: &SetSources,
    pool_path: &std::path::Path,
    lines: &[String],
    evidence: &SetEvidence,
    d: &Decision,
    seed: u64,
) -> Option<ProtocolAgent> {
    reconstruct_agent_with_pool(
        dex,
        src,
        load_meta_pool(pool_path),
        lines,
        evidence,
        d,
        seed,
    )
}

/// Reconstruction plus the fabrication metadata used by the standing
/// human-agreement coverage report.
pub struct ReconstructedDecision {
    pub agent: ProtocolAgent,
    pub active_slot: usize,
    pub revealed_moves: usize,
    pub provenance: Vec<&'static str>,
    pub imputed_pick: bool,
}

/// [`reconstruct_agent`] with a caller-supplied pool. Corpus-scale tools
/// load the JSON once and clone the parsed pool per independent seed.
pub fn reconstruct_agent_with_pool(
    dex: &Dex,
    src: &SetSources,
    pool: MetaPool,
    lines: &[String],
    evidence: &SetEvidence,
    d: &Decision,
    seed: u64,
) -> Option<ProtocolAgent> {
    reconstruct_context_with_pool(dex, src, pool, lines, evidence, d, seed)
        .map(|reconstructed| reconstructed.agent)
}

/// [`reconstruct_context_with_pool`] with a caller-supplied agent config.
///
/// Exists so a harness can vary the eval weights across arms. Everything
/// downstream of `cfg()` is reached only through here, so without this the
/// weights are silently whatever `EvalWeights::default()` happens to be —
/// which makes an A/B over an eval feature impossible to express, and hid
/// that fact behind a plausible-looking call.
pub fn reconstruct_context_with_cfg(
    dex: &Dex,
    src: &SetSources,
    pool: MetaPool,
    lines: &[String],
    evidence: &SetEvidence,
    d: &Decision,
    seed: u64,
    agent_cfg: RmConfig,
) -> Option<ReconstructedDecision> {
    reconstruct_context_inner(dex, src, pool, lines, evidence, d, seed, agent_cfg, None)
}

/// [`reconstruct_context_with_pool`] with an M18 community belief prior
/// installed on the agent before its first request, which is the only moment
/// the belief is constructed. Exists for the class-A gate: certifying the
/// marginal sampler requires replaying the corpus with it switched ON, and
/// there is no other way to reach a `ProtocolAgent`'s belief in time.
#[allow(clippy::too_many_arguments)]
pub fn reconstruct_context_with_prior(
    dex: &Dex,
    src: &SetSources,
    pool: MetaPool,
    lines: &[String],
    evidence: &SetEvidence,
    d: &Decision,
    seed: u64,
    prior: Option<std::sync::Arc<crate::prior::BeliefPrior>>,
) -> Option<ReconstructedDecision> {
    reconstruct_context_inner(dex, src, pool, lines, evidence, d, seed, cfg(), prior)
}

/// [`reconstruct_agent_with_pool`] retaining fabrication metadata.
pub fn reconstruct_context_with_pool(
    dex: &Dex,
    src: &SetSources,
    pool: MetaPool,
    lines: &[String],
    evidence: &SetEvidence,
    d: &Decision,
    seed: u64,
) -> Option<ReconstructedDecision> {
    reconstruct_context_inner(dex, src, pool, lines, evidence, d, seed, cfg(), None)
}

#[allow(clippy::too_many_arguments)]
fn reconstruct_context_inner(
    dex: &Dex,
    src: &SetSources,
    pool: MetaPool,
    lines: &[String],
    evidence: &SetEvidence,
    d: &Decision,
    seed: u64,
    agent_cfg: RmConfig,
    prior: Option<std::sync::Arc<crate::prior::BeliefPrior>>,
) -> Option<ReconstructedDecision> {
    let mut tr = ProtocolTracker::new(d.side);
    for ln in &lines[..=d.cut] {
        tr.push_line(dex, ln);
    }
    let (mons, active_slot) = tr.snapshot(d.side);
    let active_slot = active_slot?;
    if mons[active_slot].choiceless {
        return None;
    }

    let mut own_sets_json = Vec::new();
    let mut provenance = Vec::new();
    for m in &mons {
        let species = dex.species.key(m.species);
        let item = evidence.item(d.side, &m.name, species);
        let (set, prov) = fabricate_set(
            dex,
            src,
            m,
            evidence.moves(d.side, &m.name, species),
            item.map(|event| event.item.as_str()),
            item.is_some_and(|event| event.cut <= d.cut),
        );
        own_sets_json.push(set);
        provenance.push(prov);
    }
    let own_sets: Vec<nc2000_engine::battle::PokemonSet> =
        serde_json::from_value(serde_json::json!(own_sets_json.clone())).ok()?;
    let maxhps: Vec<i32> = Battle::from_fixture(dex, "1,2,3,4", &own_sets, &own_sets)
        .ok()?
        .sides[0]
        .roster
        .iter()
        .map(|p| p.maxhp)
        .collect();

    let mut picked: Vec<usize> = Vec::new();
    picked.push(active_slot);
    for (i, m) in mons.iter().enumerate() {
        if i != active_slot && m.appeared {
            picked.push(i);
        }
    }
    let mut imputed_pick = false;
    for (i, m) in mons.iter().enumerate() {
        if picked.len() >= 3 {
            break;
        }
        if !m.appeared {
            picked.push(i);
            imputed_pick = true;
        }
    }
    if picked.len() < 3 {
        return None;
    }
    picked.truncate(3);

    let act = &mons[active_slot];
    let act_set_moves: Vec<String> = own_sets_json[active_slot]["moves"]
        .as_array()
        .map(|a| {
            a.iter()
                .filter_map(|x| x.as_str().map(String::from))
                .collect()
        })
        .unwrap_or_default();
    let encore = act
        .vols
        .iter()
        .find(|(k, _)| k == "encore")
        .and_then(|(_, m)| *m);
    let disable = act
        .vols
        .iter()
        .find(|(k, _)| k == "disable")
        .and_then(|(_, m)| *m);
    // PS names the volatile on the TRAPPED side `trapped`; `meanlook` is the
    // move, and the linked status lives on the trapper. Checking for
    // `meanlook` here therefore never fired, the synthetic request said
    // "not trapped", and `legal_move_choices` offered switches that are
    // illegal — measured on the 570-battle corpus: 290 decisions where the
    // acting mon is Mean Looked, every one of them with switch actions in the
    // set, 45% of root visits spent on them, and the bot's top-1 an illegal
    // switch in the worst cases. Live play is unaffected: `import.rs` takes
    // `trapped` straight from the server's request JSON.
    let trapped = act
        .vols
        .iter()
        .any(|(k, _)| k == "trapped" || k == "meanlook" || k == "partiallytrapped");
    let uses_of = |key: &str| -> i32 {
        act.uses
            .iter()
            .find(|(id, _)| plain(dex.moves.key(*id)) == plain(key))
            .map(|(_, n)| *n)
            .unwrap_or(0)
    };
    let req_moves: Vec<serde_json::Value> = act_set_moves
        .iter()
        .map(|name| {
            let key = toid(name);
            let pk = plain(&key);
            let (pp, maxpp) = dex
                .moves
                .id(&key)
                .map(|id| {
                    let mx = dex.moves.get(id).pp as i32 * 8 / 5;
                    ((mx - uses_of(&key)).max(0), mx)
                })
                .unwrap_or((5, 5));
            let disabled = match (encore, disable) {
                (Some(em), _) => plain(dex.moves.key(em)) != pk,
                (None, Some(dm)) => plain(dex.moves.key(dm)) == pk,
                _ => false,
            };
            serde_json::json!({"id": pk, "move": name, "pp": pp, "maxpp": maxpp,
                "target": "normal", "disabled": disabled})
        })
        .collect();
    let req_mons: Vec<serde_json::Value> = picked
        .iter()
        .map(|&i| {
            let m = &mons[i];
            let cond = if m.fainted {
                "0 fnt".to_string()
            } else {
                let hp = ((m.hp_frac * maxhps[i] as f64).round() as i32).clamp(1, maxhps[i]);
                let st = m.status.as_str();
                if st.is_empty() || m.status == Status::Fnt {
                    format!("{}/{}", hp, maxhps[i])
                } else {
                    format!("{}/{} {}", hp, maxhps[i], st)
                }
            };
            let nick = if m.name.is_empty() {
                dex.species.get(m.species).name.clone()
            } else {
                m.name.clone()
            };
            let ident = format!("p{}: {}", d.side + 1, nick);
            serde_json::json!({"ident": ident, "details": details(dex, m),
                "condition": cond, "active": i == active_slot,
                "item": own_sets_json[i]["item"].as_str().map(toid).unwrap_or_default()})
        })
        .collect();
    let req = serde_json::json!({
        "active": [{"moves": req_moves, "trapped": trapped}],
        "side": {"name": format!("p{}", d.side + 1), "id": format!("p{}", d.side + 1),
                 "pokemon": req_mons},
        "rqid": d.cut as u64,
    })
    .to_string();

    let mut agent = ProtocolAgent::new(dex, d.side, pool, agent_cfg, seed);
    agent.set_own_team(own_sets);
    if let Some(prior) = prior {
        agent.set_belief_prior(prior);
    }
    for ln in &lines[..=d.cut] {
        agent.push_line(dex, ln);
    }
    agent.on_request(dex, &req).ok()?;
    Some(ReconstructedDecision {
        agent,
        active_slot,
        revealed_moves: act.uses.len().min(4),
        provenance,
        imputed_pick,
    })
}

/// Reconstruct only the synthesized battle.  Kept as the compact API used
/// by the M17e exact-equity harnesses.
pub fn reconstruct(
    dex: &Dex,
    src: &SetSources,
    pool_path: &std::path::Path,
    lines: &[String],
    evidence: &SetEvidence,
    d: &Decision,
    seed: u64,
) -> Option<Battle> {
    reconstruct_agent(dex, src, pool_path, lines, evidence, d, seed)?
        .battle()
        .cloned()
}

/// Moves publicly used by each currently-active Pokemon anywhere in the
/// complete log. This deliberately looks past `cut`: it is an offline corpus
/// label, never information a live agent may consume.
pub fn active_future_revealed_moves(
    dex: &Dex,
    battle: &Battle,
    lines: &[String],
) -> [Vec<String>; 2] {
    let evidence = collect_set_evidence(lines);
    let mut out: [Vec<String>; 2] = std::array::from_fn(|_| Vec::new());
    for (side, moves) in out.iter_mut().enumerate() {
        let Some(id) = battle.active_id(side) else {
            continue;
        };
        let name = battle.poke(id).name.to_string();
        let species = dex.species.key(battle.poke(id).species);
        moves.extend(
            evidence
                .moves(side, &name, species)
                .iter()
                .filter(|key| dex.moves.id(key).is_some())
                .cloned(),
        );
    }
    out
}

/// Research-only oracle completion for the currently active pair. Future
/// public move reveals replace only candidate slots that had not been used at
/// the reconstruction cut. State, HP, status, already-observed PP, and every
/// opponent-hidden field remain exactly as reconstructed.
///
/// This is intentionally separate from `reconstruct`: callers must opt into
/// future leakage explicitly, and product agents cannot reach this API.
pub fn complete_active_moves_from_future(
    dex: &Dex,
    battle: &mut Battle,
    lines: &[String],
) -> [Vec<String>; 2] {
    let revealed = active_future_revealed_moves(dex, battle, lines);
    for side in 0..2 {
        let Some(id) = battle.active_id(side) else {
            continue;
        };
        if battle.poke(id).transformed {
            continue;
        }
        let revealed_ids: Vec<_> = revealed[side]
            .iter()
            .filter_map(|key| dex.moves.id(key))
            .collect();
        for move_id in revealed_ids.iter().copied() {
            if battle
                .poke(id)
                .move_slots
                .iter()
                .any(|slot| slot.id == move_id)
            {
                continue;
            }
            let replacement = battle
                .poke(id)
                .move_slots
                .iter()
                .enumerate()
                .rev()
                .find(|(_, slot)| {
                    !slot.used
                        && !revealed_ids.contains(&slot.id)
                        && battle.poke(id).last_move != Some(slot.id)
                        && battle.poke(id).last_move_used != Some(slot.id)
                })
                .map(|(index, _)| index);
            let maxpp = dex.moves.get(move_id).pp as i32 * 8 / 5;
            let slot = MoveSlot {
                id: move_id,
                pp: maxpp,
                maxpp,
                disabled: false,
                used: false,
                shared: true,
            };
            let pokemon = battle.poke_mut(id);
            match replacement {
                Some(index) => {
                    pokemon.move_slots[index] = slot;
                    if index < pokemon.base_move_slots.len() {
                        pokemon.base_move_slots[index] = slot;
                    }
                }
                None if pokemon.move_slots.len() < 4 => {
                    pokemon.move_slots.push(slot);
                    pokemon.base_move_slots.push(slot);
                }
                None => {}
            }
        }
    }
    revealed
}

#[cfg(test)]
mod tests {
    use super::*;
    use nc2000_engine::battle::PokemonSet;
    use nc2000_engine::state::Gender;

    fn splash_set() -> PokemonSet {
        PokemonSet {
            name: "Pikachu".into(),
            species: "Pikachu".into(),
            item: String::new(),
            ability: String::new(),
            moves: vec!["Splash".into()],
            level: 50,
            evs: None,
            ivs: None,
            happiness: None,
            gender: None,
        }
    }

    fn transform_set() -> PokemonSet {
        PokemonSet {
            name: "Ditto".into(),
            species: "Ditto".into(),
            item: String::new(),
            ability: String::new(),
            moves: vec!["Transform".into()],
            level: 50,
            evs: None,
            ivs: None,
            happiness: None,
            gender: None,
        }
    }

    fn snapshot(dex: &Dex, species: &str, moves: &[&str]) -> MonSnapshot {
        MonSnapshot {
            species: dex.species.id(species).unwrap(),
            level: 50,
            gender: Gender::N,
            name: species.to_string(),
            appeared: true,
            active: true,
            fainted: false,
            hp_frac: 1.0,
            hp_num: 100,
            hp_den: 100,
            status: Status::None,
            rest: false,
            boosts: [0; 7],
            vols: Vec::new(),
            uses: moves
                .iter()
                .map(|key| (dex.moves.id(key).unwrap(), 1))
                .collect(),
            choiceless: false,
        }
    }

    #[test]
    fn full_log_own_moves_select_the_matching_set_and_item_is_time_aware() {
        let dex = conformance::load_dex();
        let snorlax = dex.species.id("snorlax").unwrap();
        let mut by_species = HashMap::new();
        by_species.insert(
            snorlax,
            vec![
                serde_json::json!({"species":"Snorlax","item":"Leftovers",
                    "moves":["Body Slam","Earthquake","Self-Destruct","Belly Drum"]}),
                serde_json::json!({"species":"Snorlax","item":"Mint Berry",
                    "moves":["Body Slam","Earthquake","Rest","Curse"]}),
            ],
        );
        let src = SetSources {
            by_species,
            learnsets: HashMap::new(),
            hp_dvs: HashMap::new(),
            rejected: Vec::new(),
        };
        let mon = snapshot(&dex, "snorlax", &["bodyslam", "earthquake"]);

        let (before, provenance) = fabricate_set(
            &dex,
            &src,
            &mon,
            &["rest".into()],
            Some("Mint Berry"),
            false,
        );
        assert_eq!(provenance, "cand-full");
        assert_eq!(before["item"], "Mint Berry");
        assert!(before["moves"]
            .as_array()
            .unwrap()
            .iter()
            .any(|m| m == "Rest"));

        let (after, _) =
            fabricate_set(&dex, &src, &mon, &["rest".into()], Some("Mint Berry"), true);
        assert_eq!(after["item"], "");
    }

    #[test]
    fn equal_candidate_scores_keep_the_earlier_source() {
        let dex = conformance::load_dex();
        let pikachu = dex.species.id("pikachu").unwrap();
        let mut by_species = HashMap::new();
        by_species.insert(
            pikachu,
            vec![
                serde_json::json!({"species":"Pikachu","item":"Mint Berry","moves":["Splash"]}),
                serde_json::json!({"species":"Pikachu","item":"Gold Berry","moves":["Splash"]}),
            ],
        );
        let src = SetSources {
            by_species,
            learnsets: HashMap::new(),
            hp_dvs: HashMap::new(),
            rejected: Vec::new(),
        };
        let mon = snapshot(&dex, "pikachu", &["splash"]);
        let (set, _) = fabricate_set(&dex, &src, &mon, &[], None, false);
        assert_eq!(set["item"], "Mint Berry");
    }

    #[test]
    fn evidence_excludes_generic_called_moves_but_keeps_sleep_talk_calls() {
        let lines = vec![
            "|switch|p1a: Snorlax|Snorlax, L50, M|100/100".into(),
            "|move|p1a: Snorlax|Body Slam|p2a: Pikachu".into(),
            "|move|p1a: Snorlax|Thunder|p2a: Pikachu|[from] Metronome".into(),
            "|move|p1a: Snorlax|Rest|p1a: Snorlax|[from] Sleep Talk".into(),
            "|move|p1a: Snorlax|Struggle|p2a: Pikachu|[from] Sleep Talk".into(),
            "|move|p1a: Snorlax|Recharge|p1a: Snorlax".into(),
            "|move|p1a: Snorlax|Pursuit|p2a: Pikachu|[from] Pursuit".into(),
            "|-enditem|p1a: Snorlax|Mint Berry|[eat]".into(),
        ];
        let evidence = collect_set_evidence(&lines);
        assert_eq!(
            evidence.moves(0, "", "snorlax"),
            ["bodyslam", "rest", "pursuit"]
        );
        let item = evidence.item(0, "", "snorlax").unwrap();
        assert_eq!(item.cut, 7);
        assert_eq!(item.item, "Mint Berry");
    }

    #[test]
    fn evidence_excludes_plain_release_of_called_two_turn_moves() {
        // battle 215: Metronome's charge line names its caller, but the
        // following-turn release does not. `-prepare` is the authoritative
        // indication that the plain line is a continuation.
        let lines = vec![
            "|switch|p1a: Snorlax|Snorlax, L55, F|100/100".into(),
            "|move|p1a: Snorlax|Metronome|p1a: Snorlax".into(),
            "|move|p1a: Snorlax|Razor Wind||[from] Metronome|[still]".into(),
            "|-prepare|p1a: Snorlax|Razor Wind".into(),
            "|upkeep".into(),
            "|turn|2".into(),
            "|move|p1a: Snorlax|Razor Wind|p2a: Shuckle|[miss]".into(),
            "|move|p1a: Snorlax|Metronome|p1a: Snorlax".into(),
            "|move|p1a: Snorlax|Solar Beam||[from] Metronome|[still]".into(),
            "|-prepare|p1a: Snorlax|Solar Beam".into(),
            "|upkeep".into(),
            "|turn|3".into(),
            "|move|p1a: Snorlax|Solar Beam|p2a: Shuckle".into(),
        ];
        let evidence = collect_set_evidence(&lines);
        assert_eq!(evidence.moves(0, "Snorlax", "snorlax"), ["metronome"]);
    }

    #[test]
    fn failed_called_two_turn_marker_does_not_hide_a_later_real_move() {
        // `[still]` alone is not sufficient: PS can attach it to a failed
        // move. Without `-prepare`, a later ordinary use is submitted-set
        // evidence.
        let lines = vec![
            "|switch|p1a: Snorlax|Snorlax, L55, F|100/100".into(),
            "|move|p1a: Snorlax|Solar Beam||[from] Metronome|[still]".into(),
            "|-fail|p1a: Snorlax".into(),
            "|upkeep".into(),
            "|turn|2".into(),
            "|move|p1a: Snorlax|Solar Beam|p2a: Shuckle".into(),
        ];
        let evidence = collect_set_evidence(&lines);
        assert_eq!(evidence.moves(0, "Snorlax", "snorlax"), ["solarbeam"]);
    }

    #[test]
    fn transformed_moves_are_not_submitted_set_evidence_and_switch_or_replace_clears_it() {
        let switched = vec![
            "|switch|p1a: Mew|Mew, L50|100/100".into(),
            "|move|p1a: Mew|Transform|p2a: Snorlax".into(),
            "|-transform|p1a: Mew|p2a: Snorlax".into(),
            "|move|p1a: Mew|Body Slam|p2a: Snorlax".into(),
            "|switch|p1a: Pikachu|Pikachu, L50|100/100".into(),
            "|switch|p1a: Mew|Mew, L50|100/100".into(),
            "|move|p1a: Mew|Psychic|p2a: Snorlax".into(),
        ];
        let evidence = collect_set_evidence(&switched);
        assert_eq!(evidence.moves(0, "Mew", "mew"), ["transform", "psychic"]);

        let replaced = vec![
            "|switch|p1a: Mew|Mew, L50|100/100".into(),
            "|move|p1a: Mew|Transform|p2a: Snorlax".into(),
            "|-transform|p1a: Mew|p2a: Snorlax".into(),
            "|move|p1a: Mew|Body Slam|p2a: Snorlax".into(),
            "|replace|p1a: Mew|Mew, L50|100/100".into(),
            "|move|p1a: Mew|Psychic|p2a: Snorlax".into(),
        ];
        let evidence = collect_set_evidence(&replaced);
        assert_eq!(evidence.moves(0, "Mew", "mew"), ["transform", "psychic"]);
    }

    #[test]
    fn ditto_transform_corpus_excerpt_does_not_leak_copied_move_to_future_oracle() {
        // battle-gen2...pbs-F-20260401-121508-7c046d6831be.raw.log
        // lines 51-66: Ditto transforms into Snorlax, then uses Body Slam.
        let dex = conformance::load_dex();
        let team = vec![transform_set()];
        let mut battle = Battle::from_fixture(&dex, "1,2,3,4", &team, &team).unwrap();
        let p1 = battle.legal_choices(&dex, 0)[0];
        let p2 = battle.legal_choices(&dex, 1)[0];
        battle.apply_choices(&dex, [Some(p1), Some(p2)]).unwrap();
        let lines = vec![
            "|switch|p1a: Ditto|Ditto, L50|100/100".into(),
            "|move|p1a: Ditto|Transform|p2a: Snorlax".into(),
            "|-transform|p1a: Ditto|p2a: Snorlax".into(),
            "|move|p1a: Ditto|Body Slam|p2a: Snorlax".into(),
        ];

        let evidence = collect_set_evidence(&lines);
        assert_eq!(evidence.moves(0, "Ditto", "ditto"), ["transform"]);
        assert_eq!(
            active_future_revealed_moves(&dex, &battle, &lines)[0],
            ["transform"]
        );
    }

    #[test]
    fn tracker_does_not_retain_transformed_move_as_base_set_evidence() {
        let dex = conformance::load_dex();
        let mut tracker = ProtocolTracker::new(0);
        for line in [
            "|poke|p1|Ditto, L50|",
            "|poke|p1|Pikachu, L50|",
            "|poke|p2|Snorlax, L50, M|",
            "|switch|p1a: Ditto|Ditto, L50|100/100",
            "|switch|p2a: Snorlax|Snorlax, L50, M|100/100",
            "|turn|2",
            "|move|p1a: Ditto|Transform|p2a: Snorlax",
            "|-transform|p1a: Ditto|p2a: Snorlax",
            "|turn|3",
            "|move|p1a: Ditto|Body Slam|p2a: Snorlax",
            "|switch|p1a: Pikachu|Pikachu, L50|100/100",
            "|switch|p1a: Ditto|Ditto, L50|100/100",
        ] {
            tracker.push_line(&dex, line);
        }
        let (mons, _) = tracker.snapshot(0);
        let moves: Vec<_> = mons[0]
            .uses
            .iter()
            .map(|(id, _)| dex.moves.key(*id))
            .collect();
        assert_eq!(moves, ["transform"]);
    }

    #[test]
    fn future_move_oracle_counts_sleep_talk_calls_but_not_other_called_moves() {
        let dex = conformance::load_dex();
        let team = vec![splash_set()];
        let mut battle = Battle::from_fixture(&dex, "1,2,3,4", &team, &team).unwrap();
        let p1 = battle.legal_choices(&dex, 0)[0];
        let p2 = battle.legal_choices(&dex, 1)[0];
        battle.apply_choices(&dex, [Some(p1), Some(p2)]).unwrap();
        let lines = vec![
            "|move|p1a: Pikachu|Rest|p1a: Pikachu".into(),
            "|move|p1a: Pikachu|Thunderbolt|p2a: Pikachu|[from] Metronome".into(),
            "|move|p2a: Pikachu|Rest|p2a: Pikachu|[from] Sleep Talk".into(),
        ];

        let revealed = active_future_revealed_moves(&dex, &battle, &lines);
        assert_eq!(
            revealed,
            [vec!["rest".to_string()], vec!["rest".to_string()]]
        );
        complete_active_moves_from_future(&dex, &mut battle, &lines);
        let rest = dex.moves.id("rest").unwrap();
        for side in 0..2 {
            let id = battle.active_id(side).unwrap();
            assert!(battle
                .poke(id)
                .move_slots
                .iter()
                .any(|slot| slot.id == rest));
        }
    }
}
