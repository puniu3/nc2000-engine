//! M10a observation tracker: what one player legitimately knows about the
//! opponent's team, accumulated over a battle.
//!
//! # Tap point
//!
//! Two channels, both driven by `Observer::observe(&Battle)` called at the
//! bot's real decision points (never inside search iterations):
//!
//! 1. **State diff** — reads opponent fields whose *every mutation path in
//!    this engine is publicly announced*, so the diff carries exactly the
//!    information a competent human extracts from the protocol:
//!    - `base_move_slots`: `pp < maxpp || used` ⇔ the move was executed at
//!      least once with a public `|move|` line. Audited mutation paths:
//!      `deduct_pp` is called only from `run_move` (public `|move|`) and
//!      Spite (public `-activate`, targets the already-revealed last move);
//!      Mystery Berry's PP restore is public and only reaches a slot that
//!      hit 0 PP (already revealed). Transform/Mimic overlay slots are
//!      `shared = false`, so foreign moves never touch the base slots.
//!    - `item`: transitions only. `Some(x) → None` (use_item / eat_item /
//!      take_item — all emit `-enditem` or the Thief `-item ... [of]` line),
//!      `None → Some(y)` (Thief steal, public `-item`). The standing value
//!      is stored privately for diffing but never exposed; only transitions
//!      (all public) produce knowledge.
//!    - preview-public facts read once at construction: species, level,
//!      gender (the `|poke|` details) and *item presence* (the `|poke|`
//!      line's item flag).
//!    This channel works with the protocol log disabled.
//!
//! 2. **Log scan** — incremental parse of `battle.log` when the observed
//!    battle happens to run log-on. Adds the reveals that leave no state
//!    trace: Leftovers residual heals (`-heal ... [from] item: Leftovers`),
//!    Focus Band procs (`-activate ... item: Focus Band`), and moves called
//!    by Sleep Talk (`|move| ... [from] Sleep Talk` — in gen 2 the called
//!    move is from the sleeper's own set). Degrades silently to channel 1
//!    when the log is off.
//!
//! Rejected taps: *pure log parsing* (dies in log-off arenas), *instrumenting
//! apply_choices* (would hand the tracker the opponent's submitted choice,
//! which is NOT public when the move is cancelled invisibly — sleep/para
//! `|cant|` hides the selection — i.e. a psychic tap by construction; it
//! would also touch engine code the bit-exactness constraint protects), and
//! a *tracker-owned log-on mirror battle* (needs the applied choices plumbed
//! in — the same psychic tap — and adds 2x real-game stepping for no
//! information beyond the two channels above).
//!
//! M10b should run the *outer* (real) battle log-on where possible — the
//! cost is one game's protocol log; search clones inside `SkuctSearch`
//! always disable the log themselves.
//!
//! # What is deliberately NOT tracked (conservative by design)
//!
//! Quick Claw (silent in this engine's log; humans infer it from impossible
//! ordering), Bright Powder (unattributed misses), King's Rock (unattributed
//! flinches), and stat-boost items (silent). Missing a reveal only leaves the belief a superset —
//! it can never false-filter the true team.

use nc2000_engine::dex::{toid, Dex, ItemId, MoveId, SpeciesId};
use nc2000_engine::state::{Battle, Gender};

pub fn move_matches(dex: &Dex, slot: MoveId, revealed: MoveId) -> bool {
    slot == revealed
        || (dex.moves.key(revealed) == "hiddenpower"
            && dex.moves.key(slot).starts_with("hiddenpower"))
}

/// Public knowledge about one opponent roster mon's held item.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct ItemObs {
    /// The item the mon *brought* (what set filtering matches against).
    /// `None` = identity unknown; `Some(None)` = known to have started
    /// empty-handed (its Thief succeeded).
    pub original: Option<Option<ItemId>>,
    /// The *currently held* item when publicly known (the determinizer keeps
    /// the true item field exactly when this is `Some`). `Some(None)` =
    /// known consumed/stolen away.
    pub current: Option<Option<ItemId>>,
    /// A gain event (Thief steal) was observed — later reveals no longer
    /// identify the original item. `pub(crate)` so a hand-entered position
    /// can round-trip the whole channel (`position.rs`), not just the two
    /// halves a reader would guess at.
    pub(crate) gained: bool,
}

impl ItemObs {
    /// `Some(x) → None` transition or `-enditem` line: x left the mon.
    fn lost(&mut self, x: ItemId) -> bool {
        let mut dirty = self.current != Some(None);
        self.current = Some(None);
        if !self.gained && self.original.is_none() {
            self.original = Some(Some(x));
            dirty = true;
        }
        dirty
    }

    /// `None → Some(y)` transition or `-item` line: y arrived (Thief).
    fn gained(&mut self, y: ItemId) -> bool {
        let dirty = self.current != Some(Some(y)) || !self.gained;
        self.current = Some(Some(y));
        if self.original.is_none() {
            // Thief only steals into an empty hand.
            self.original = Some(None);
        }
        self.gained = true;
        dirty
    }

    /// Passive reveal of a held item (Leftovers heal, Focus Band proc).
    /// Only upgrades unknown state — a stale `-activate` right after an
    /// `-enditem` (Mystery Berry) must not resurrect the item.
    fn revealed_held(&mut self, x: ItemId) -> bool {
        let mut dirty = false;
        if self.current.is_none() {
            self.current = Some(Some(x));
            dirty = true;
        }
        if !self.gained && self.original.is_none() {
            self.original = Some(Some(x));
            dirty = true;
        }
        dirty
    }
}

/// Everything legitimately known about one opponent roster mon.
#[derive(Clone, Debug)]
pub struct MonObs {
    // ---- public at team preview
    pub species: SpeciesId,
    pub level: u8,
    pub gender: Gender,
    /// Nickname (public whenever it appears in a log line; used only to
    /// resolve log subjects back to roster slots).
    pub name: String,
    /// The `|poke|` preview line's item flag: the mon brought *an* item.
    pub preview_has_item: bool,
    // ---- accumulated in battle
    /// Moves known to be in the mon's set (each publicly executed at least
    /// once, or named by a Sleep Talk call). Grows monotonically.
    pub revealed_moves: Vec<MoveId>,
    pub hp_type_mask: u16,
    pub item: ItemObs,
    /// The mon has switched in at least once (its pick is public).
    pub appeared: bool,
}

impl MonObs {
    /// EXP-SIV frozen-pin support: this observation with the in-battle
    /// reveal channels erased (revealed moves, item knowledge). Preview
    /// facts and pick publicity are kept so determinization stays coherent
    /// with the public battle state while a stubbornly-held wrong candidate
    /// is imputed verbatim (docs/EXP-signature-info-value.md).
    pub(crate) fn preview_only(&self) -> MonObs {
        MonObs { hp_type_mask: u16::MAX, revealed_moves: Vec::new(), item: ItemObs::default(), ..self.clone() }
    }
}

/// Observation tracker for one side of one battle. Construct at battle
/// start (team preview — item *presence* is read then), call `observe`
/// at every real decision point.
#[derive(Clone)]
pub struct Observer {
    side: usize,
    mons: Vec<MonObs>,
    /// Private diff snapshot of the opponent's item fields — never exposed;
    /// only its (publicly-announced) transitions produce knowledge.
    prev_item: Vec<Option<ItemId>>,
    log_pos: usize,
    /// Per-mon log-channel suppression: while a Transform copy is active
    /// (tracked from the log lines themselves, in order), `|move|` lines may
    /// name any move of the copied set, so none of them is evidence.
    log_suppress: Vec<bool>,
    /// Per-mon: the single move Mimic overwrote its own slot with. Mimic
    /// replaces exactly one slot, and PS names the copied move on the
    /// `|-activate|<mon>|move: Mimic|<Move>` line, so only that move has to
    /// be dropped — the mon's other three slots are still its own and every
    /// use of them is a genuine reveal. Cleared with the mon's stay, because
    /// `clearVolatile` restores `baseMoveSlots` on switch-out.
    mimic_overlay: Vec<Option<MoveId>>,
    /// Per-mon: a two-turn move a CALLER (Metronome / Mirror Move) put into
    /// its charge turn. The release line is a plain `|move|` with no `[from]`,
    /// so without this the caller's victim move is credited to the mon's own
    /// set — an over-reveal, which is worse than a miss: five "revealed" moves
    /// for four slots is unsatisfiable and makes `Belief::sync_checked` fail
    /// closed on the pinned/open-sheet path. `corpus.rs::collect_set_evidence`
    /// has carried this rule offline since the corpus harness was built; this
    /// is the same rule on the live channel.
    called_charging: Vec<Option<MoveId>>,
    /// The last line was a called move announcing its charge (`[from]` +
    /// `[still]`), awaiting the `-prepare` that confirms which move it is.
    pending_call: Option<(usize, MoveId)>,
    hp_targets: [Option<(String, Vec<String>)>; 2],
    hp_pending: Option<(usize, String, Vec<String>)>,
    revision: u64,
}

impl ItemObs {
    /// Rebuild the channel from a serialized position (`position.rs`). The
    /// three parts are not independent — `gained` decides whether a later
    /// reveal may still identify `original` — so they are set together
    /// rather than through three public fields.
    pub fn from_parts(
        original: Option<Option<ItemId>>,
        current: Option<Option<ItemId>>,
        gained: bool,
    ) -> ItemObs {
        ItemObs { original, current, gained }
    }
}

impl Observer {
    /// Solver mode: construct the reveal channel directly from a
    /// hand-entered position instead of replaying protocol lines. Same
    /// contract as `from_mons` — the state-diff channel never runs, so
    /// `observe` must not be called on the result.
    pub fn from_position(
        dex: &Dex,
        spec: &crate::position::PositionSpec,
    ) -> Result<Observer, String> {
        let foe = spec.foe();
        let item = |k: &crate::position::ItemKnowledge| -> Result<Option<Option<ItemId>>, String> {
            match k.to_obs() {
                None => Ok(None),
                Some(None) => Ok(Some(None)),
                Some(Some(key)) => dex
                    .items
                    .id(&toid(key))
                    .map(|i| Some(Some(i)))
                    .ok_or_else(|| format!("unknown item `{key}`")),
            }
        };
        let mut mons = Vec::new();
        for m in &spec.sides[foe].mons {
            if m.hp_type_mask == 0 {
                return Err("Hidden Power type constraint is empty".into());
            }
            if m.hp_type_mask != u16::MAX && !m.revealed_moves.iter().any(|m| toid(m).starts_with("hiddenpower")) {
                return Err("Hidden Power type constraint requires a revealed move".into());
            }
            let species = dex
                .species
                .id(&toid(&m.species))
                .ok_or_else(|| format!("unknown species `{}`", m.species))?;
            if m.hp_type_mask != u16::MAX {
                let gender = match m.gender.as_str() { "M" => Gender::M, "F" => Gender::F, _ => Gender::N };
                if m.hp_type_mask & crate::hp_evidence::possible_types(dex, species, gender) == 0 {
                    return Err("Hidden Power type contradicts public gender".into());
                }
            }
            if m.hp_type_mask != u16::MAX && m.revealed_moves.iter().any(|key| {
                let key = toid(key);
                key.strip_prefix("hiddenpower").filter(|suffix| !suffix.is_empty()).and_then(|suffix| {
                    crate::hp_evidence::TYPES.iter().position(|t| t.eq_ignore_ascii_case(suffix))
                }).is_some_and(|index| m.hp_type_mask & (1 << index) == 0)
            }) {
                return Err("Hidden Power type constraint contradicts a revealed move".into());
            }
            let mut revealed = Vec::new();
            for key in &m.revealed_moves {
                let id = dex
                    .moves
                    .id(&toid(key))
                    .ok_or_else(|| format!("unknown move `{key}`"))?;
                if !revealed.contains(&id) {
                    revealed.push(id);
                }
            }
            mons.push(MonObs {
                species,
                level: m.level,
                gender: match m.gender.as_str() {
                    "M" => Gender::M,
                    "F" => Gender::F,
                    _ => Gender::N,
                },
                name: m.name.clone(),
                preview_has_item: m.item_flag,
                revealed_moves: revealed,
                hp_type_mask: m.hp_type_mask,
                item: ItemObs::from_parts(item(&m.item_original)?, item(&m.item_current)?, m.item_gained),
                appeared: m.appeared,
            });
        }
        let mut observer = Observer::from_mons(spec.side, mons);
        for (side, team) in spec.sides.iter().enumerate() {
            if let Some(slot) = team.active {
                let mon = &team.mons[slot];
                if mon.transformed_into.is_none() && !mon.volatiles.iter().any(|v| matches!(v.key.as_str(), "typechange" | "foresight")) {
                    let species = dex.species.get(dex.species.id(&toid(&mon.species)).unwrap());
                    let name = if mon.name.is_empty() { species.name.clone() } else { mon.name.clone() };
                    observer.hp_targets[side] = Some((name, species.types.clone()));
                }
            }
        }
        Ok(observer)
    }

    /// M15 protocol mode: construct from preview-public facts parsed out of
    /// the protocol (`|poke|` lines) instead of a battle. The state-diff
    /// channel never runs (there is no true battle to diff — `observe` must
    /// not be called); all knowledge arrives via `ingest_line`. Nicknames
    /// are learned from switch lines by the caller (`set_name`) — subject
    /// resolution needs them before the mon's first `|move|` line, and
    /// switch lines always precede them.
    pub(crate) fn from_mons(side: usize, mons: Vec<MonObs>) -> Observer {
        let n = mons.len();
        Observer {
            side,
            mons,
            prev_item: vec![None; n],
            log_pos: 0,
            log_suppress: vec![false; n],
            mimic_overlay: vec![None; n],
            called_charging: vec![None; n],
            pending_call: None,
            hp_targets: [None, None],
            hp_pending: None,
            revision: 0,
        }
    }

    /// Protocol mode: feed one player-visible protocol line through the log
    /// channel (the only channel — see `from_mons`).
    pub(crate) fn ingest_line(&mut self, line: &str, dex: &Dex) {
        if self.scan_line(line, dex) {
            self.revision += 1;
        }
    }

    /// Protocol mode: a mon appeared under `name` (resolves log subjects).
    pub(crate) fn set_name(&mut self, slot: usize, name: &str) {
        if self.mons[slot].name != name {
            self.mons[slot].name = name.to_string();
        }
        if !self.mons[slot].appeared {
            self.mons[slot].appeared = true;
            self.revision += 1;
        }
    }

    pub fn new(battle: &Battle, side: usize) -> Observer {
        let opp = 1 - side;
        let mons = battle.sides[opp]
            .roster
            .iter()
            .map(|p| MonObs {
                species: p.species,
                level: p.level,
                gender: p.gender,
                name: p.name.as_str().to_string(),
                preview_has_item: p.item.is_some(),
                revealed_moves: Vec::new(),
                hp_type_mask: u16::MAX,
                item: ItemObs::default(),
                appeared: false,
            })
            .collect::<Vec<_>>();
        let prev_item = battle.sides[opp].roster.iter().map(|p| p.item).collect();
        let n = mons.len();
        Observer {
            side,
            mons,
            prev_item,
            log_pos: 0,
            log_suppress: vec![false; n],
            mimic_overlay: vec![None; n],
            called_charging: vec![None; n],
            pending_call: None,
            hp_targets: [None, None],
            hp_pending: None,
            revision: 0,
        }
    }

    pub fn side(&self) -> usize {
        self.side
    }

    pub fn opp(&self) -> usize {
        1 - self.side
    }

    /// Per opponent roster slot, aligned with `battle.sides[opp].roster`.
    pub fn mons(&self) -> &[MonObs] {
        &self.mons
    }

    pub fn without_hp_type_evidence(&self) -> Self {
        let mut observer = self.clone();
        for mon in &mut observer.mons { mon.hp_type_mask = u16::MAX; }
        observer
    }

    /// Bumped whenever new information arrives (belief sync trigger).
    pub fn revision(&self) -> u64 {
        self.revision
    }

    /// Ingest everything that became visible since the last call. Call at
    /// every decision point of the *real* battle (never on search clones).
    pub fn observe(&mut self, battle: &Battle, dex: &Dex) {
        let mut dirty = false;
        let opp = self.opp();

        // ---- channel 1: state diff over public-equivalent fields
        for (slot, p) in battle.sides[opp].roster.iter().enumerate() {
            let mo = &mut self.mons[slot];
            if !mo.appeared && (p.previously_switched_in > 0 || p.is_active) {
                mo.appeared = true;
                dirty = true;
            }
            // moves: base-slot usage marks (every path is a public |move|)
            for s in p.base_move_slots.iter() {
                if (s.pp < s.maxpp || s.used) && !mo.revealed_moves.contains(&s.id) {
                    mo.revealed_moves.push(s.id);
                    dirty = true;
                }
            }
            // item: transitions only (every path is publicly announced)
            let cur = p.item;
            let prev = self.prev_item[slot];
            if cur != prev {
                match (prev, cur) {
                    (Some(x), None) => dirty |= mo.item.lost(x),
                    (None, Some(y)) => dirty |= mo.item.gained(y),
                    (Some(x), Some(y)) => {
                        // unreachable in gen 2 (no in-place swap); defensive
                        if !mo.item.gained && mo.item.original.is_none() {
                            mo.item.original = Some(Some(x));
                        }
                        dirty |= mo.item.gained(y);
                    }
                    (None, None) => unreachable!(),
                }
                self.prev_item[slot] = cur;
            }
        }

        // ---- channel 2: incremental protocol-log scan (log-on battles)
        if battle.log.len() < self.log_pos {
            // log was cleared (set_log_enabled(false)); lose the tail
            self.log_pos = battle.log.len();
        }
        for i in self.log_pos..battle.log.len() {
            let line = battle.log[i].clone();
            dirty |= self.scan_line(&line, dex);
        }
        self.log_pos = battle.log.len();

        if dirty {
            self.revision += 1;
        }
    }

    // ------------------------------------------------------------ log scan

    fn scan_line(&mut self, line: &str, dex: &Dex) -> bool {
        let Some(body) = line.strip_prefix('|') else { return false };
        let parts: Vec<&str> = body.split('|').collect();
        let cmd = parts.first().copied().unwrap_or("");
        // The charge announcement and its `-prepare` are adjacent; anything
        // in between means this was not a charging call after all.
        let pending = self.pending_call.take();
        let hp_dirty = self.scan_hp_evidence(&parts, dex);
        let dirty = match cmd {
            "-prepare" => {
                let subject = parts.get(1).copied().unwrap_or("");
                let named = parts.get(2).copied().unwrap_or("");
                if let (Some(m), Some(id)) = (self.opp_subject(subject), dex.moves.id(&toid(named)))
                {
                    if pending == Some((m, id)) {
                        self.called_charging[m] = Some(id);
                    }
                }
                false
            }
            "cant" | "-anim" => {
                if let Some(m) = self.opp_subject(parts.get(1).copied().unwrap_or("")) {
                    self.called_charging[m] = None;
                }
                false
            }
            "move" => self.scan_move(&parts, dex),
            "switch" | "drag" | "faint" => {
                // clear_volatile drops Transform/Mimic overlays on exit; a
                // switch line's subject is the incoming mon, so clear all
                // suppression for the side (only actives carry overlays).
                if self.subject_is_opp_side(parts.get(1).copied().unwrap_or("")) {
                    self.log_suppress.iter_mut().for_each(|s| *s = false);
                    // Mimic's overwritten slot goes back to Mimic on exit
                    self.mimic_overlay.iter_mut().for_each(|o| *o = None);
                    // a charge dies with the mon that was holding it
                    self.called_charging.iter_mut().for_each(|c| *c = None);
                }
                false
            }
            "-transform" => {
                if let Some(m) = self.opp_subject(parts.get(1).copied().unwrap_or("")) {
                    self.log_suppress[m] = true;
                }
                false
            }
            "-activate" => {
                let Some(m) = self.opp_subject(parts.get(1).copied().unwrap_or("")) else {
                    return false;
                };
                let what = parts.get(2).copied().unwrap_or("");
                if what == "move: Mimic" {
                    // PS names the copied move on this line, so exactly one
                    // slot becomes foreign. Suppressing the whole mon instead
                    // would drop every later use of its other three slots --
                    // the design's class-A example, "ignoring an already-
                    // revealed move". Fall back to whole-mon suppression only
                    // if the name does not resolve.
                    match parts.get(3).and_then(|n| dex.moves.id(&toid(n))) {
                        Some(copied) => self.mimic_overlay[m] = Some(copied),
                        None => self.log_suppress[m] = true,
                    }
                    return false;
                }
                if let Some(item_name) = what.strip_prefix("item: ") {
                    if let Some(id) = dex.items.id(&toid(item_name)) {
                        return self.mons[m].item.revealed_held(id);
                    }
                }
                false
            }
            "-enditem" => {
                let Some(m) = self.opp_subject(parts.get(1).copied().unwrap_or("")) else {
                    return false;
                };
                match dex.items.id(&toid(parts.get(2).copied().unwrap_or(""))) {
                    Some(id) => self.mons[m].item.lost(id),
                    None => false,
                }
            }
            "-item" => {
                let subject = parts.get(1).copied().unwrap_or("");
                let Some(id) = dex.items.id(&toid(parts.get(2).copied().unwrap_or(""))) else {
                    return false;
                };
                if let Some(m) = self.opp_subject(subject) {
                    // opponent gained an item (their Thief stole ours)
                    return self.mons[m].item.gained(id);
                }
                // our Thief stole theirs: `-item <us> <item> [from] move: Thief [of] <them>`
                if parts.iter().any(|p| *p == "[from] move: Thief") {
                    if let Some(of) = parts.iter().find_map(|p| p.strip_prefix("[of] ")) {
                        if let Some(v) = self.opp_subject(of) {
                            return self.mons[v].item.lost(id);
                        }
                    }
                }
                false
            }
            "-heal" => {
                let Some(m) = self.opp_subject(parts.get(1).copied().unwrap_or("")) else {
                    return false;
                };
                if let Some(item_name) =
                    parts.iter().find_map(|p| p.strip_prefix("[from] item: "))
                {
                    if let Some(id) = dex.items.id(&toid(item_name)) {
                        return self.mons[m].item.revealed_held(id);
                    }
                }
                false
            }
            _ => false,
        };
        dirty || hp_dirty
    }

    fn scan_hp_evidence(&mut self, parts: &[&str], dex: &Dex) -> bool {
        if !cfg!(feature = "hp-type-evidence") { return false; }
        let command = parts[0];
        let subject = parts.get(1).copied().unwrap_or("");
        let side = subject.as_bytes().get(1).and_then(|c| match c { b'1' => Some(0), b'2' => Some(1), _ => None });
        match command {
            "switch" | "drag" => {
                self.hp_pending = None;
                if let Some(side) = side {
                    self.hp_targets[side] = subject.split_once(": ").zip(parts.get(2)).and_then(|((_, name), details)| {
                        let species = dex.species.id(&toid(details.split(',').next()?))?;
                        Some((name.to_string(), dex.species.get(species).types.clone()))
                    });
                }
            }
            "faint" | "-transform" => {
                self.hp_pending = None;
                if let Some(side) = side { self.hp_targets[side] = None; }
            }
            "-start" if parts.get(2).is_some_and(|s| matches!(toid(s).as_str(), "typechange" | "foresight")) => {
                self.hp_pending = None;
                if let Some(side) = side { self.hp_targets[side] = None; }
            }
            "move" | "turn" | "upkeep" | "cant" => self.hp_pending = None,
            "-supereffective" | "-resisted" => {
                if let Some((slot, name, types)) = self.hp_pending.take() {
                    if side == Some(self.side) && subject.split_once(": ").is_some_and(|(_, n)| n == name) {
                        let old = self.mons[slot].hp_type_mask;
                        let mask = old & crate::hp_evidence::effect_mask(dex, &types, command == "-supereffective")
                            & crate::hp_evidence::possible_types(dex, self.mons[slot].species, self.mons[slot].gender);
                        if mask != 0 && mask != old {
                            self.mons[slot].hp_type_mask = mask;
                            return true;
                        }
                    }
                }
            }
            _ => {}
        }
        false
    }

    fn scan_move(&mut self, parts: &[&str], dex: &Dex) -> bool {
        let Some(m) = self.opp_subject(parts.get(1).copied().unwrap_or("")) else {
            return false;
        };
        if self.log_suppress[m] {
            // Transform copy active: plain |move| lines (and even Sleep Talk
            // calls) may name any move of the copied set.
            return false;
        }
        let named = parts.get(2).copied().unwrap_or("");
        let Some(id) = dex.moves.id(&toid(named)) else { return false };
        if self.mimic_overlay[m] == Some(id) {
            // the one slot Mimic overwrote. Sleep Talk selects from the
            // CURRENT slots, so this must be checked before the `[from]`
            // rules, not only for plain lines.
            return false;
        }
        let from = parts
            .iter()
            .find_map(|p| p.strip_prefix("[from] "))
            .map(|f| f.strip_prefix("move: ").unwrap_or(f));
        if let Some(from) = from {
            let from_id = dex.moves.id(&toid(from));
            // `[from]` naming the executing move itself is not a call at all:
            // Pursuit's interception of a switching target logs
            // `|move|p2a: X|Pursuit|p1a: Y|[from] Pursuit`, and that is the mon
            // publicly using its own slot. Sleep Talk is the other exception —
            // it selects from the user's own set. Everything else (Metronome,
            // Mirror Move) executes a FOREIGN move.
            let self_named = from_id.is_some_and(|f| move_matches(dex, id, f));
            let sleep_talk = toid(from) == "sleeptalk";
            if !self_named && !sleep_talk {
                // A called TWO-TURN move announces its charge here and then
                // releases on a plain `|move|` line that carries no `[from]`.
                // Remember it so the release is not read as the mon's own.
                if parts.iter().any(|p| *p == "[still]") {
                    self.pending_call = Some((m, id));
                }
                return false;
            }
        }
        if from.is_none() && self.called_charging[m] == Some(id) {
            // the release of the charge a caller started: not a submitted slot
            self.called_charging[m] = None;
            return false;
        }
        // synthetic non-set moves
        if matches!(dex.moves.key(id), "struggle" | "recharge") {
            return false;
        }
        if dex.moves.key(id) == "hiddenpower" {
            if let Some(target) = parts.get(3) {
                if target.as_bytes().get(1) == Some(&(b'1' + self.side as u8)) {
                    if let Some((name, types)) = &self.hp_targets[self.side] {
                        if target.split_once(": ").is_some_and(|(_, n)| n == name) {
                            self.hp_pending = Some((m, name.clone(), types.clone()));
                        }
                    }
                }
            }
        }
        if !self.mons[m].revealed_moves.contains(&id) {
            self.mons[m].revealed_moves.push(id);
            return true;
        }
        false
    }

    // -------------------------------------------------- subject resolution

    /// `"p2a: Nick"` / `"p2: Nick"` → opponent roster slot (unique-nickname
    /// match; ambiguity or foreign side → `None`, i.e. skip = conservative).
    fn opp_subject(&self, s: &str) -> Option<usize> {
        if !self.subject_is_opp_side(s) {
            return None;
        }
        let rest = &s[2..];
        let rest = rest.strip_prefix(|c: char| c.is_ascii_lowercase()).unwrap_or(rest);
        let name = rest.strip_prefix(": ")?;
        let mut found = None;
        for (i, m) in self.mons.iter().enumerate() {
            if m.name == name {
                if found.is_some() {
                    return None;
                }
                found = Some(i);
            }
        }
        found
    }

    fn subject_is_opp_side(&self, s: &str) -> bool {
        let b = s.as_bytes();
        b.len() >= 4 && b[0] == b'p' && b[1] == b'1' + self.opp() as u8
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use conformance::load_dex;

    fn one_mon_observer(dex: &Dex, species: &str, name: &str) -> Observer {
        let mons = vec![MonObs {
            species: dex.species.id(&toid(species)).expect("species"),
            level: 50,
            gender: Gender::N,
            name: name.to_string(),
            preview_has_item: false,
            revealed_moves: Vec::new(),
            hp_type_mask: u16::MAX,
            item: Default::default(),
            appeared: true,
        }];
        // side 0 observes side 1 (`p2a:` subjects).
        Observer::from_mons(0, mons)
    }

    fn revealed(obs: &Observer, dex: &Dex) -> Vec<String> {
        obs.mons[0]
            .revealed_moves
            .iter()
            .map(|&id| dex.moves.key(id).to_string())
            .collect()
    }

    #[cfg(not(feature = "hp-type-evidence"))]
    #[test]
    fn hp_effectiveness_inference_is_disabled_by_default() {
        let dex = load_dex();
        let mut obs = one_mon_observer(&dex, "Aerodactyl", "A");
        for line in ["|switch|p1a: N|Snorlax, L50|100/100",
            "|move|p2a: A|Hidden Power|p1a: N", "|-supereffective|p1a: N"] {
            obs.ingest_line(line, &dex);
        }
        assert_eq!(obs.mons[0].hp_type_mask, u16::MAX);
    }

    #[cfg(feature = "hp-type-evidence")]
    #[test]
    fn hp_evidence_intersects_and_respects_type_changes_and_callers() {
        let dex = load_dex();
        let mut obs = one_mon_observer(&dex, "Aerodactyl", "A");
        for line in [
            "|switch|p1a: Z|Zapdos, L50|100/100",
            "|move|p2a: A|Hidden Power|p1a: Z",
            "|-crit|p1a: Z",
            "|-supereffective|p1a: Z",
        ] { obs.ingest_line(line, &dex); }
        assert_eq!(obs.mons[0].hp_type_mask, (1 << 13) | (1 << 4));
        let revision = obs.revision();
        for line in [
            "|switch|p1a: S|Steelix, L50|100/100",
            "|move|p2a: A|Hidden Power|p1a: S",
            "|-resisted|p1a: S",
        ] { obs.ingest_line(line, &dex); }
        assert_eq!(obs.mons[0].hp_type_mask, 1 << 4);
        assert!(obs.revision() > revision);
        for prelude in [
            "|-start|p1a: N|typechange|Ghost",
            "|-transform|p1a: N|p2a: A",
            "|-start|p1a: N|Foresight",
        ] {
            let mut obs = one_mon_observer(&dex, "Aerodactyl", "A");
            for line in ["|switch|p1a: N|Snorlax, L50|100/100", prelude,
                "|move|p2a: A|Hidden Power|p1a: N", "|-supereffective|p1a: N"] {
                obs.ingest_line(line, &dex);
            }
            assert_eq!(obs.mons[0].hp_type_mask, u16::MAX);
        }
        let mut obs = one_mon_observer(&dex, "Aerodactyl", "A");
        for line in [
            "|switch|p1a: N|Snorlax, L50|100/100",
            "|move|p2a: A|Hidden Power|p1a: N|[from] Metronome",
            "|-supereffective|p1a: N",
        ] { obs.ingest_line(line, &dex); }
        assert_eq!(obs.mons[0].hp_type_mask, u16::MAX);
        for line in ["|move|p2a: A|Hidden Power|p1a: N|[from] Sleep Talk", "|-supereffective|p1a: N"] {
            obs.ingest_line(line, &dex);
        }
        assert_eq!(obs.mons[0].hp_type_mask, 1);
    }

    /// A caller charging a two-turn move must not credit the victim move to
    /// the mon's own set. Corpus battle 215 is the observed case: p1 Snorlax
    /// ended with FIVE revealed moves for four slots (substitute, doubleteam,
    /// attract, metronome, razorwind) because Metronome's Razor Wind released
    /// on a plain `|move|` line. Five facts for four slots is unsatisfiable,
    /// so `Belief::sync_checked` fails closed on the pinned/open-sheet path —
    /// the shipped product's own configuration.
    #[test]
    fn called_two_turn_release_is_not_a_reveal() {
        let dex = load_dex();
        let mut obs = one_mon_observer(&dex, "Snorlax", "Snorlax");
        for line in [
            "|move|p2a: Snorlax|Metronome|p2a: Snorlax",
            "|move|p2a: Snorlax|Razor Wind||[from] Metronome|[still]",
            "|-prepare|p2a: Snorlax|Razor Wind",
            "|move|p2a: Snorlax|Razor Wind|p1a: Target",
        ] {
            obs.ingest_line(line, &dex);
        }
        assert_eq!(revealed(&obs, &dex), vec!["metronome".to_string()]);
    }

    /// `[from]` naming the executing move itself is a genuine reveal, not a
    /// call. Pursuit's interception of a switching target is the case that
    /// occurs in the corpus (4 lines, all Umbreon): dropping it means the bot
    /// never learns a move it publicly watched land, which is the design's own
    /// class-A example — "ignoring an already-revealed move".
    #[test]
    fn a_self_named_from_tag_is_a_reveal() {
        let dex = load_dex();
        let mut obs = one_mon_observer(&dex, "Umbreon", "Umbreon");
        obs.ingest_line("|move|p2a: Umbreon|Pursuit|p1a: Rapidash|[from] Pursuit", &dex);
        assert_eq!(revealed(&obs, &dex), vec!["pursuit".to_string()]);
    }

    /// The rule must not eat a genuine reveal: the same move used normally on
    /// a later turn is the mon's own.
    #[test]
    fn an_uncalled_two_turn_move_still_reveals() {
        let dex = load_dex();
        let mut obs = one_mon_observer(&dex, "Snorlax", "Snorlax");
        for line in [
            "|move|p2a: Snorlax|Razor Wind||[still]",
            "|-prepare|p2a: Snorlax|Razor Wind",
            "|move|p2a: Snorlax|Razor Wind|p1a: Target",
        ] {
            obs.ingest_line(line, &dex);
        }
        assert_eq!(revealed(&obs, &dex), vec!["razorwind".to_string()]);
    }

    /// Mimic overwrites exactly ONE slot, and PS names the copied move on
    /// the `-activate` line. Suppressing the whole mon instead loses every
    /// later use of its other three slots — an under-reveal of moves the bot
    /// publicly watched land. The copied move itself stays uncredited, and so
    /// does a Sleep Talk call that selects it (Sleep Talk picks from the
    /// CURRENT slots, which include the overwritten one).
    #[test]
    fn mimic_suppresses_only_the_copied_slot() {
        let dex = load_dex();
        let mut obs = one_mon_observer(&dex, "Zapdos", "Zapdos");
        for line in [
            "|move|p2a: Zapdos|Mimic|p1a: Snorlax",
            "|-activate|p2a: Zapdos|move: Mimic|Body Slam",
            // the copied slot: not the mon's own, by either route
            "|move|p2a: Zapdos|Body Slam|p1a: Snorlax",
            "|move|p2a: Zapdos|Body Slam|p1a: Snorlax|[from] Sleep Talk",
            // its own remaining slots stay reveals
            "|move|p2a: Zapdos|Thunder|p1a: Snorlax",
            "|move|p2a: Zapdos|Rest|p2a: Zapdos",
        ] {
            obs.ingest_line(line, &dex);
        }
        assert_eq!(
            revealed(&obs, &dex),
            vec!["mimic".to_string(), "thunder".to_string(), "rest".to_string()]
        );
    }

    /// `clearVolatile` puts the Mimic slot back on switch-out, so the copied
    /// move must stop being suppressed — otherwise a genuine later use by a
    /// DIFFERENT mon of the same name, or by this one after it really learns
    /// it, would be dropped forever.
    #[test]
    fn a_mimic_overlay_dies_with_the_mons_stay() {
        let dex = load_dex();
        let mut obs = one_mon_observer(&dex, "Zapdos", "Zapdos");
        for line in [
            "|move|p2a: Zapdos|Mimic|p1a: Snorlax",
            "|-activate|p2a: Zapdos|move: Mimic|Body Slam",
            "|switch|p2a: Zapdos|Zapdos, L50|100/100",
            "|move|p2a: Zapdos|Body Slam|p1a: Snorlax",
        ] {
            obs.ingest_line(line, &dex);
        }
        assert_eq!(
            revealed(&obs, &dex),
            vec!["mimic".to_string(), "bodyslam".to_string()]
        );
    }

    /// Transform stays whole-mon suppression: the copy replaces all four
    /// slots, so no `|move|` line from it is evidence about the base set.
    #[test]
    fn transform_still_suppresses_every_slot() {
        let dex = load_dex();
        let mut obs = one_mon_observer(&dex, "Ditto", "Ditto");
        for line in [
            "|move|p2a: Ditto|Transform|p1a: Snorlax",
            "|-transform|p2a: Ditto|p1a: Snorlax",
            "|move|p2a: Ditto|Body Slam|p1a: Snorlax",
            "|move|p2a: Ditto|Rest|p2a: Ditto",
        ] {
            obs.ingest_line(line, &dex);
        }
        assert_eq!(revealed(&obs, &dex), vec!["transform".to_string()]);
    }

    /// An interrupted charge releases the tracking, so a later genuine use of
    /// the same move is still credited.
    #[test]
    fn an_interrupted_charge_does_not_suppress_forever() {
        let dex = load_dex();
        let mut obs = one_mon_observer(&dex, "Snorlax", "Snorlax");
        for line in [
            "|move|p2a: Snorlax|Razor Wind||[from] Metronome|[still]",
            "|-prepare|p2a: Snorlax|Razor Wind",
            "|cant|p2a: Snorlax|par",
            "|move|p2a: Snorlax|Razor Wind|p1a: Target",
        ] {
            obs.ingest_line(line, &dex);
        }
        assert_eq!(revealed(&obs, &dex), vec!["razorwind".to_string()]);
    }
}
