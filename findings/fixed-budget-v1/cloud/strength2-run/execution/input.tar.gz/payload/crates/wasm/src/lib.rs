//! M9a wasm bridge: the JS-facing API over the engine + bot crates.
//!
//! Design: coarse-grained JSON-string API (all structured data crosses the
//! boundary as JSON text) — cheap to evolve, trivial to consume, and the
//! per-call volume is tiny next to search work. Four classes, exported under
//! clean JS names:
//!
//! - `Dex` — the loaded game data. Embedded copy (`new Dex()`) or
//!   caller-supplied JSON (`Dex.fromJson(text)`).
//! - `Battle` — one battle, protocol log ON by default (the GUI narrates
//!   from `takeNewLog`). Choices go in as PS-canonical strings (the same
//!   strings `legalChoices` returns), exactly the fixture/inputLog format.
//! - `Searcher` — persistent stepped skuct search over ONE decision point
//!   (state-keyed UCB argmax — the perfect-info flagship). The M9c ponder
//!   worker pumps `step(n)` in slices and reads `best()` when the move is
//!   wanted; create a fresh `Searcher` whenever the battle advances.
//! - `BlindSearcher` (M10c) — the imperfect-info agent: one instance per
//!   GAME (it accumulates the M10a observer/belief), `observe()` fed the
//!   current battle at each decision point (which also snapshots a fresh
//!   stepped `BlindSearch` — same `step`/`best` ponder shape as `Searcher`),
//!   baked-table preview via the belief when the opponent's pool identity
//!   has publicly resolved, `beliefInfo()` for the UI. `pinOpponent` (M12)
//!   switches it to the open-team-sheet product policy: belief pinned to
//!   the opponent's true sets (picks stay hidden), preview by direct
//!   signature lookup.
//! - `PreviewTables` — the M8 baked team-preview equilibria. JS fetches
//!   `meta-pool.json` + `pair-*.json` and feeds them in as strings;
//!   `resolve` returns the matchup's mixed/argmax policies, `sample` draws
//!   a seeded pick as a ready-to-apply choice string.
//!
//! Objects share the dex via `Rc` (wasm is single-threaded), so JS passes
//! the dex only at construction time.

use std::rc::Rc;
use std::sync::Arc;

use wasm_bindgen::prelude::*;

use nc2000_bot::fork::{Arena, ForkSpec, Info, Policy};
use nc2000_bot::player::PlayerChannel;
use nc2000_bot::preview::{MetaPool, TableSet};
use nc2000_bot::position::PositionSpec;
use nc2000_bot::{
    baked_preview_pick, open_preview_pick, BeliefPrior, Belief, BlindSearch, Observer,
    ProtocolAgent, RmConfig, SkuctSearch, SplitMix64,
};
use nc2000_engine::battle::{Outcome, PokemonSet, SearchChoice};
use nc2000_engine::dex::{Category, Dex};
use nc2000_engine::state::{Battle, Pokemon, RequestKind, Status, BOOST_NAMES};
use nc2000_engine::validate::{canonicalize_team, validate_team, Learnsets};
use nc2000_engine::replay::{Recorder, Replay};

/// data/gen2stadium2.json baked into the binary (~416 KB, ~150 KB gzipped
/// over the wire) — one fetch fewer and no path plumbing for the common
/// case; `Dex.fromJson` exists for callers that want to ship it separately.
const EMBEDDED_DEX: &str = include_str!("../../../data/gen2stadium2.json");

/// data/learnsets-gen2.json baked in too (~124 KB raw, ~13 KB gzipped —
/// well under the dex's embed precedent, and the validator is useless
/// without it); `Validator.fromJson` exists for callers shipping their own.
const EMBEDDED_LEARNSETS: &str = include_str!("../../../data/learnsets-gen2.json");

fn js_err(e: impl std::fmt::Debug) -> JsError {
    JsError::new(&format!("{e:?}"))
}

// -------------------------------------------------------------------- Dex

#[wasm_bindgen(js_name = Dex)]
pub struct WasmDex {
    dex: Rc<Dex>,
}

#[wasm_bindgen(js_class = Dex)]
impl WasmDex {
    /// The embedded gen2stadium2 dex.
    #[wasm_bindgen(constructor)]
    pub fn new() -> Result<WasmDex, JsError> {
        Self::from_json(EMBEDDED_DEX)
    }

    /// Construct from caller-supplied dex JSON (`data/gen2stadium2.json`
    /// contents).
    #[wasm_bindgen(js_name = fromJson)]
    pub fn from_json(text: &str) -> Result<WasmDex, JsError> {
        let dex = Dex::from_json(text).map_err(js_err)?;
        Ok(WasmDex { dex: Rc::new(dex) })
    }
}

// -------------------------------------------------------------- Validator

/// M14a team validator + canonicalizer (`nc2000_engine::validate`): checks
/// custom teams against the gen2nc2000 rules the way PS's TeamValidator
/// does, from embedded data only (dex + learnsets — no network). Move
/// legality is a FLAT per-species set: cross-move compatibility constraints
/// are deliberately not encoded, so a small superset of true PS legality is
/// accepted (never the reverse — oracle-certified by
/// `tools/validate-oracle.js`).
#[wasm_bindgen(js_name = Validator)]
pub struct WasmValidator {
    dex: Rc<Dex>,
    learnsets: Learnsets,
}

#[wasm_bindgen(js_class = Validator)]
impl WasmValidator {
    /// Validator over the embedded learnsets (`data/learnsets-gen2.json`).
    #[wasm_bindgen(constructor)]
    pub fn new(dex: &WasmDex) -> Result<WasmValidator, JsError> {
        Self::from_json(dex, EMBEDDED_LEARNSETS)
    }

    /// Construct from caller-supplied learnsets JSON.
    #[wasm_bindgen(js_name = fromJson)]
    pub fn from_json(dex: &WasmDex, learnsets_json: &str) -> Result<WasmValidator, JsError> {
        let learnsets = Learnsets::from_json(learnsets_json).map_err(|e| JsError::new(&e))?;
        Ok(WasmValidator { dex: dex.dex.clone(), learnsets })
    }

    /// Validate a team (the same JSON array the `Battle` constructor takes).
    /// Returns findings JSON `{ok, errors, findings: [{severity, code,
    /// mon, slot, ...params}]}` — `severity` is `"error"` (PS's validator
    /// rejects it) or `"fix"` (legal, but PS/the engine silently
    /// canonicalize it; `canonicalizeTeam` applies these). Machine-readable
    /// codes only — M14b renders the messages.
    #[wasm_bindgen(js_name = validateTeam)]
    pub fn validate_team(&self, team_json: &str) -> String {
        validate_team(&self.dex, &self.learnsets, team_json).to_string()
    }

    /// Canonicalize a team: apply every `fix` plus the derivable errors
    /// (HP DV, SpD:=SpA mirrors, gender/shiny from DVs, typed-Hidden-Power
    /// DV spreads, EV clamps/fills, nickname repairs, duplicate moves).
    /// Returns `{ok, team, applied, errors}` — `team` is ready for the
    /// `Battle` constructor when `ok`; `errors` lists what remains
    /// (species/level/move legality, clauses — user intent, not auto-fixed).
    #[wasm_bindgen(js_name = canonicalizeTeam)]
    pub fn canonicalize_team(&self, team_json: &str) -> String {
        canonicalize_team(&self.dex, &self.learnsets, team_json).to_string()
    }
}

// ----------------------------------------------------------------- Battle

#[wasm_bindgen(js_name = Battle)]
pub struct WasmBattle {
    dex: Rc<Dex>,
    battle: Battle,
    log_cursor: usize,
    recorder: Option<Recorder>,
}

#[wasm_bindgen(js_class = Battle)]
impl WasmBattle {
    /// `p1_team` / `p2_team`: JSON arrays of PokemonSet (the fixture
    /// `p1team` / meta-pool `sets` shape). `seed`: PS `Gen5RNG.getSeed()`
    /// format — four decimal 16-bit limbs, comma-joined (e.g. `"1,2,3,4"`).
    /// The battle starts at team preview with the protocol log ON.
    #[wasm_bindgen(constructor)]
    pub fn new(
        dex: &WasmDex,
        p1_team: &str,
        p2_team: &str,
        seed: &str,
    ) -> Result<WasmBattle, JsError> {
        let p1: Vec<PokemonSet> = serde_json::from_str(p1_team).map_err(js_err)?;
        let p2: Vec<PokemonSet> = serde_json::from_str(p2_team).map_err(js_err)?;
        let battle = Battle::from_fixture(&dex.dex, seed, &p1, &p2).map_err(js_err)?;
        let recorder = Some(Recorder::new(&dex.dex, &battle, [p1, p2], seed));
        Ok(WasmBattle { dex: dex.dex.clone(), battle, log_cursor: 0, recorder })
    }

    /// A `nc2000-fork-v1` document's battle, log ON and empty. Equal seeds
    /// give identical battles, which is how a worker builds its mirror.
    #[wasm_bindgen(js_name = fromFork)]
    pub fn from_fork(dex: &WasmDex, fork_json: &str, seed: u32) -> Result<WasmBattle, JsError> {
        let fork = ForkSpec::parse(fork_json).map_err(|e| JsError::new(&e))?;
        let battle = fork.battle(&dex.dex, seed as u64).map_err(|e| JsError::new(&e))?;
        Ok(WasmBattle { dex: dex.dex.clone(), battle, log_cursor: 0, recorder: None })
    }

    #[wasm_bindgen(js_name = setPreviewLevelCap)]
    pub fn set_preview_level_cap(&mut self, side: usize, cap: Option<u32>) -> Result<(), JsError> {
        if side > 1 || self.battle.turn != 0 {
            return Err(JsError::new("preview cap requires side 0 or 1 before battle start"));
        }
        self.battle.preview_level_caps[side] = cap;
        if let Some(r) = &mut self.recorder { r.replay.caps = self.battle.preview_level_caps; }
        Ok(())
    }

    /// JSON `[bool, bool]` — which sides owe a choice. `[false, false]`
    /// means the battle has ended.
    #[wasm_bindgen(js_name = needsChoice)]
    pub fn needs_choice(&self) -> String {
        serde_json::to_string(&self.battle.needs_choice()).unwrap()
    }

    /// JSON array of choice objects for `side` (empty ⇔ the side owes
    /// nothing). Every object carries `input` — the PS-canonical string to
    /// pass back to `applyChoice` — plus UI metadata per kind:
    /// move: id/name/type/category/basePower/accuracy/pp/maxpp/target;
    /// switch: pos/species/name/level/hp/maxhp/status;
    /// team: slots (1-based display positions, lead first).
    #[wasm_bindgen(js_name = legalChoices)]
    pub fn legal_choices(&mut self, side: usize) -> String {
        let choices = self.battle.legal_choices(&self.dex, side);
        let arr: Vec<serde_json::Value> =
            choices.iter().map(|&c| choice_json(&self.battle, &self.dex, side, c)).collect();
        serde_json::to_string(&arr).unwrap()
    }

    /// The `legalChoices` input naming the same choice as `input`, which may
    /// be in the protocol's form (`move hiddenpower`); `null` when illegal.
    #[wasm_bindgen(js_name = resolveChoice)]
    pub fn resolve_choice(&mut self, side: usize, input: &str) -> Option<String> {
        let legal = self.battle.legal_choices(&self.dex, side);
        nc2000_bot::fork::find_choice(&self.dex, &legal, input).map(|c| c.to_input(&self.dex))
    }

    /// Submit one side's choice as its PS-canonical string (`"move surf"` /
    /// `"switch 3"` / `"team 1, 3, 5"` / `"pass"`). When the last owing side
    /// submits, the battle advances to the next request point (or ends).
    #[wasm_bindgen(js_name = applyChoice)]
    pub fn apply_choice(&mut self, side: usize, input: &str) -> Result<(), JsError> {
        if let Some(r) = &mut self.recorder {
            r.choose(&self.dex, &mut self.battle, side, input).map_err(js_err)
        } else {
            self.battle.choose(&self.dex, side, input).map_err(js_err)
        }
    }

    #[wasm_bindgen(js_name = exportKifu)]
    pub fn export_kifu(&mut self, open: bool, bot_side: usize) -> Result<String, JsError> {
        let r = self.recorder.as_mut().ok_or_else(|| JsError::new("this battle has no replay origin"))?;
        r.replay.open = open;
        r.replay.bot_side = bot_side;
        r.replay.encode(&self.dex).map_err(|e| JsError::new(&e))
    }

    /// `"p1"` / `"p2"` / `"tie"`, or `null` while the battle is running.
    pub fn outcome(&self) -> Option<String> {
        self.battle.outcome().map(|o| {
            match o {
                Outcome::P1Win => "p1",
                Outcome::P2Win => "p2",
                Outcome::Tie => "tie",
            }
            .to_string()
        })
    }

    pub fn turn(&self) -> u16 {
        self.battle.turn
    }

    /// Current PRNG seed in PS format — the native≡wasm parity invariant
    /// (seed equality = RNG-consumption-order equality).
    pub fn seed(&self) -> String {
        self.battle.prng.seed_str()
    }

    /// Full render-ready state as JSON: per side (active index, party in
    /// display order with hp/status/boosts/moves+pp/item/types), field
    /// (weather, pseudo-weathers), side conditions, request kinds, turn.
    /// Semantics follow the `play` example's panel — full information, both
    /// sides; the GUI decides what the viewer may see.
    #[wasm_bindgen(js_name = stateView)]
    pub fn state_view(&self) -> String {
        state_view_json(&self.battle, &self.dex).to_string()
    }

    /// Protocol log lines appended since the last call (JSON array of raw
    /// PS protocol lines, `|split|`-structure included). The GUI narrates
    /// from these; the `play` example's renderer is the semantics reference.
    #[wasm_bindgen(js_name = takeNewLog)]
    pub fn take_new_log(&mut self) -> String {
        let lines = &self.battle.log[self.log_cursor..];
        let out = serde_json::to_string(lines).unwrap();
        self.log_cursor = self.battle.log.len();
        out
    }

    /// Search mode: disable the protocol log (the human-facing battle keeps
    /// it ON; searchers clone the battle and disable it themselves).
    #[wasm_bindgen(js_name = setLogEnabled)]
    pub fn set_log_enabled(&mut self, on: bool) {
        self.battle.set_log_enabled(on);
    }
}

// ---------------------------------------------------------- PlayerChannel

/// One side's player stream over a `Battle`, as a PS client receives it.
#[wasm_bindgen(js_name = PlayerChannel)]
pub struct WasmPlayerChannel {
    channel: PlayerChannel,
}

#[wasm_bindgen(js_class = PlayerChannel)]
impl WasmPlayerChannel {
    #[wasm_bindgen(constructor)]
    pub fn new(side: usize) -> Result<WasmPlayerChannel, JsError> {
        if side > 1 {
            return Err(JsError::new("side must be 0 or 1"));
        }
        Ok(WasmPlayerChannel { channel: PlayerChannel::new(side) })
    }

    /// JSON `{lines, request, legal_actions}`: the lines visible to this side
    /// since the previous frame, and its current request.
    pub fn frame(&mut self, battle: &mut WasmBattle) -> Result<String, JsError> {
        let frame = self
            .channel
            .frame(&mut battle.battle, &battle.dex)
            .map_err(|e| JsError::new(&e))?;
        Ok(serde_json::to_string(&frame).unwrap())
    }
}

// --------------------------------------------------------------- Searcher

const SEARCH_PROFILES: &str = include_str!("../../../data/search-profiles.json");

/// Exploration constant of a named profile in `data/search-profiles.json`:
/// `blind` is the live product; `open` is retired and only replays records
/// made under it.
fn profile_c(name: &str) -> f64 {
    let profiles: serde_json::Value =
        serde_json::from_str(SEARCH_PROFILES).expect("data/search-profiles.json parses");
    profiles[name]["c"].as_f64().expect("search profile carries c")
}

/// Exploration constant of the true-state research `Searcher` when the
/// caller gives none; no product door constructs that searcher.
const RESEARCH_SKUCT_C: f64 = 1.0;

/// Per-decision searcher settings = the gate-measured `skuct` configuration
/// (`RmConfig` defaults with rule = Ucb) at exploration constant `c`.
fn skuct_config(c: f64, hp_buckets: Option<i32>) -> RmConfig {
    RmConfig {
        rule: nc2000_bot::smmcts::SelRule::Ucb,
        c,
        hp_buckets: hp_buckets.map(|b| b as i64).unwrap_or(16),
        ..RmConfig::default()
    }
}

#[wasm_bindgen(js_name = Searcher)]
pub struct WasmSearcher {
    dex: Rc<Dex>,
    search: SkuctSearch,
    side: usize,
}

#[wasm_bindgen(js_class = Searcher)]
impl WasmSearcher {
    /// Snapshot the battle's CURRENT decision point and search it for
    /// `side`. The searcher stays valid (and keeps improving under `step`)
    /// until the battle advances — then create a fresh one. `seed` drives
    /// the searcher's own RNG (chance resampling + tie-breaking);
    /// `c` (UCB exploration, default 1.0 — this true-state searcher is a
    /// research tool, not the product) and `hpBuckets` (state-key HP
    /// abstraction, default 16).
    #[wasm_bindgen(constructor)]
    pub fn new(
        battle: &WasmBattle,
        side: usize,
        seed: u32,
        c: Option<f64>,
        hp_buckets: Option<i32>,
    ) -> WasmSearcher {
        let cfg = skuct_config(c.unwrap_or(RESEARCH_SKUCT_C), hp_buckets);
        let search = SkuctSearch::new(&battle.battle, &battle.dex, cfg, seed as u64);
        WasmSearcher { dex: battle.dex.clone(), search, side }
    }

    /// Pump `n` iterations (each: clone root + fresh chance seed + one
    /// select/expand/rollout/backprop pass), then return control to JS.
    /// Returns total iterations run so far. The ponder loop calls this in
    /// small slices (e.g. 250) to stay responsive.
    pub fn step(&mut self, n: u32) -> u32 {
        self.search.step(&self.dex, n)
    }

    pub fn iterations(&self) -> u32 {
        self.search.iterations()
    }

    /// Current best choice (argmax root visits — the skuct play rule) as a
    /// ready-to-apply input string. `null` if the side owes nothing.
    pub fn best(&self) -> Option<String> {
        self.search.best(self.side).map(|c| c.to_input(&self.dex))
    }

    /// JSON: `{iterations, preview, actions: [{input, visits, mean, frac}]}`
    /// — the root visit distribution (frac = visits share) plus per-action
    /// mean value in [0,1] from this side's perspective. Sorted by visits,
    /// descending.
    #[wasm_bindgen(js_name = rootPolicy)]
    pub fn root_policy(&self) -> String {
        serde_json::json!({
            "iterations": self.search.iterations(),
            "preview": self.search.is_preview(),
            "actions": policy_rows(
                &self.dex,
                self.search.actions(self.side),
                self.search.visits(self.side),
                &self.search.means(self.side),
            ),
        })
        .to_string()
    }
}

/// Root visit rows for `rootPolicy` (shared by `Searcher`/`BlindSearcher`).
/// Forced spots (one legal action) bypass the visit statistics inside the
/// search; report the trivial point mass instead of zeros. Same for a
/// searcher that has not stepped yet: uniform.
fn policy_rows(
    dex: &Dex,
    acts: &[SearchChoice],
    visits: &[u32],
    means: &[f64],
) -> Vec<serde_json::Value> {
    let total: u32 = visits.iter().sum();
    let fallback = if acts.is_empty() { 0.0 } else { 1.0 / acts.len() as f64 };
    let mut rows: Vec<serde_json::Value> = acts
        .iter()
        .zip(visits.iter().zip(means))
        .map(|(&a, (&n, &m))| {
            serde_json::json!({
                "input": a.to_input(dex),
                "visits": n,
                "mean": m,
                "frac": if total > 0 { n as f64 / total as f64 } else { fallback },
            })
        })
        .collect();
    rows.sort_by(|a, b| b["visits"].as_u64().cmp(&a["visits"].as_u64()));
    rows
}

// ---------------------------------------------------------- BlindSearcher

#[wasm_bindgen(js_name = BlindSearcher)]
pub struct WasmBlindSearcher {
    dex: Rc<Dex>,
    cfg: RmConfig,
    side: usize,
    tables: TableSet,
    observer: Observer,
    belief: Belief,
    /// Open-team-sheet mode (M12, `pinOpponent`): the belief is pinned to
    /// the opponent's true sets and preview resolves both sides by
    /// signature (public) instead of through pool identification.
    pinned: bool,
    /// M18: has the first `observe()` run? A belief prior is accepted only
    /// before it — see `setBeliefPrior`'s third refusal.
    observed: bool,
    rng: SplitMix64,
    search: Option<BlindSearch>,
    baked: Option<SearchChoice>,
}

#[wasm_bindgen(js_class = BlindSearcher)]
impl WasmBlindSearcher {
    /// The M10 imperfect-info agent for `side`, one instance per GAME:
    /// it accumulates what that side legitimately observes (public state
    /// diffs + protocol log — run the observed battle log-ON) and keeps a
    /// belief over the meta pool (`pool_json` = `meta-pool.json` contents).
    /// Construct right after the battle (at team preview); feed baked pair
    /// tables with `addPair` for belief-mediated table previews; then per
    /// decision point call `observe(battle)` and pump `step(n)` / read
    /// `best()` exactly like `Searcher`. `seed` drives the agent's own RNG
    /// (determinization sampling, equilibrium sampling, tie-breaking).
    #[wasm_bindgen(constructor)]
    pub fn new(
        battle: &WasmBattle,
        side: usize,
        pool_json: &str,
        seed: u32,
        c: Option<f64>,
        hp_buckets: Option<i32>,
    ) -> Result<WasmBlindSearcher, JsError> {
        let pool: MetaPool = serde_json::from_str(pool_json).map_err(js_err)?;
        let tables = TableSet::from_pool(&battle.dex, &pool);
        let observer = Observer::new(&battle.battle, side);
        let belief = Belief::new(&battle.dex, &pool, &observer);
        Ok(WasmBlindSearcher {
            dex: battle.dex.clone(),
            cfg: skuct_config(c.unwrap_or_else(|| profile_c("blind")), hp_buckets),
            side,
            tables,
            observer,
            belief,
            pinned: false,
            observed: false,
            rng: SplitMix64::new(seed as u64),
            search: None,
            baked: None,
        })
    }

    /// Open-team-sheet mode (M12 product policy): pin the belief to the
    /// opponent's TRUE team (`team_json` = the same JSON array the Battle
    /// was constructed with — pool or custom). Determinizations then equal
    /// the truth except for hidden picks: which 3 of 6 + lead stay hidden
    /// until revealed (unseen pick identities are resampled, the mid-turn
    /// pending-move tell is scrubbed). Preview switches to the direct
    /// table lookup — both sheets are public, so the baked pair answers
    /// whenever the matchup is baked, collision pair included. Call once,
    /// right after construction (at team preview).
    ///
    /// M18 note: this REPLACES the belief wholesale with
    /// `Belief::pinned_checked`, whose `prior` is `None` — so a belief prior
    /// installed before this call is dropped structurally, not by a guard.
    /// (`setBeliefPrior` refuses outright in the other order.)
    #[wasm_bindgen(js_name = pinOpponent)]
    pub fn pin_opponent(&mut self, team_json: &str) -> Result<(), JsError> {
        let sets: Vec<PokemonSet> = serde_json::from_str(team_json).map_err(js_err)?;
        self.belief =
            Belief::pinned_checked(&self.dex, "opponent", &sets, &self.observer).map_err(js_err)?;
        self.pinned = true;
        Ok(())
    }

    /// Own canonical set + opponent public roster, at preview only.
    #[wasm_bindgen(js_name = compiledPreviewKey)]
    pub fn compiled_preview_key(&self, battle: &WasmBattle) -> Option<String> {
        nc2000_bot::compiled_preview::key(&battle.battle, self.side)
    }

    #[wasm_bindgen(js_name = compiledPreviewBuild)]
    pub fn compiled_preview_build(&self) -> String {
        nc2000_bot::compiled_preview::build_fingerprint().to_string()
    }

    /// Feed one baked pair table (`data/preview-tables-v0/pair-*.json`
    /// contents) for the belief-mediated preview lookup.
    #[wasm_bindgen(js_name = addPair)]
    pub fn add_pair(&mut self, pair_json: &str) -> Result<(), JsError> {
        self.tables.add_pair_json(pair_json).map_err(|e| JsError::new(&e))
    }

    /// Feed the current battle at a decision point: ingest everything that
    /// became visible, re-filter the belief, and snapshot a fresh stepped
    /// search (any previous decision's search is dropped). At a team
    /// preview where the belief is a singleton and the pair is baked, the
    /// M8 mixed table plays instead: `bakedPreview()`/`best()` return the
    /// table pick immediately and `step` is a no-op.
    pub fn observe(&mut self, battle: &WasmBattle) -> Result<(), JsError> {
        self.observed = true;
        self.observer.observe(&battle.battle, &self.dex);
        self.belief
            .sync_checked(&self.dex, &self.observer)
            .map_err(js_err)?;
        self.baked = None;
        let seed = self.rng.next();
        let search =
            BlindSearch::new(&battle.battle, &self.dex, self.cfg.clone(), self.side, seed);
        if search.is_preview() {
            // Pinned (open sheet): both sheets public — resolve the pair
            // directly by signature, no identification condition. Else the
            // M10 belief-mediated lookup (singleton identification only).
            let pick = if self.pinned {
                open_preview_pick(&self.tables, &battle.battle, self.side, &mut self.rng)
            } else {
                baked_preview_pick(
                    &self.tables,
                    &self.belief,
                    &battle.battle,
                    self.side,
                    &mut self.rng,
                )
            };
            if let Some(c) = pick {
                if search.actions().contains(&c) {
                    self.baked = Some(c);
                }
            }
        }
        self.search = Some(search);
        Ok(())
    }

    /// The baked-table preview pick when it applies at the current decision
    /// point (ready-to-apply input string), else `null` — the caller then
    /// pumps the search.
    #[wasm_bindgen(js_name = bakedPreview)]
    pub fn baked_preview(&self) -> Option<String> {
        self.baked.map(|c| c.to_input(&self.dex))
    }

    /// Pump `n` blind iterations (each on a fresh belief determinization).
    /// Returns total iterations run at this decision point. No-op when the
    /// baked preview already decided.
    pub fn step(&mut self, n: u32) -> Result<u32, JsError> {
        let search = self.search.as_mut().ok_or_else(|| {
            JsError::new("BlindSearcher.step before observe")
        })?;
        if self.baked.is_some() {
            return Ok(search.iterations());
        }
        Ok(search.step(&self.dex, &self.belief, &self.observer, n))
    }

    pub fn iterations(&self) -> u32 {
        self.search.as_ref().map_or(0, |s| s.iterations())
    }

    /// Current best choice (baked table pick, or argmax visits over the
    /// global information-set root) as a ready-to-apply input string.
    /// `null` if the side owes nothing (or before `observe`).
    pub fn best(&self) -> Option<String> {
        if let Some(c) = self.baked {
            return Some(c.to_input(&self.dex));
        }
        self.search.as_ref()?.best().map(|c| c.to_input(&self.dex))
    }

    /// JSON: `{iterations, preview, baked, actions: [...]}` — same row
    /// shape as `Searcher.rootPolicy`, over the global root stats. A baked
    /// preview reports its point mass.
    #[wasm_bindgen(js_name = rootPolicy)]
    pub fn root_policy(&self) -> String {
        let (iterations, preview) = match &self.search {
            Some(s) => (s.iterations(), s.is_preview()),
            None => (0, false),
        };
        if let Some(c) = self.baked {
            return serde_json::json!({
                "iterations": iterations,
                "preview": preview,
                "baked": true,
                "actions": [{
                    "input": c.to_input(&self.dex),
                    "visits": 0,
                    "mean": 0.5,
                    "frac": 1.0,
                }],
            })
            .to_string();
        }
        let rows = match &self.search {
            Some(s) => policy_rows(&self.dex, s.actions(), s.visits(), &s.means()),
            None => Vec::new(),
        };
        serde_json::json!({
            "iterations": iterations,
            "preview": preview,
            "baked": false,
            "actions": rows,
        })
        .to_string()
    }

    /// JSON: `{count, fallback, candidates: [pool team ids still alive]}` —
    /// the bot's current read of the opponent's team. `count` 1 = publicly
    /// identified; `fallback` true = no pool team is consistent (a custom
    /// team; imputation runs on a synthesized roster).
    #[wasm_bindgen(js_name = beliefInfo)]
    pub fn belief_info(&self) -> String {
        let candidates: Vec<&str> =
            self.belief.alive().iter().map(|&i| self.belief.candidate_id(i)).collect();
        serde_json::json!({
            "count": self.belief.candidate_count(),
            "fallback": self.belief.is_fallback(),
            "candidates": candidates,
        })
        .to_string()
    }

    /// M18: install the community belief prior from the table's JSON TEXT
    /// (the contents of `data/belief-prior-v0.sample.json`, or of whatever
    /// file the user pointed the browser at — wasm has no filesystem, so the
    /// page reads the bytes and hands them over as a string). Returns the
    /// `belief_prior_report` JSON rather than throwing: the interpreter is
    /// total, so a typo degrades into `warnings` the caller can surface
    /// instead of the bot silently playing with no prior.
    ///
    /// Governs **only** the blind (non-pinned) fallback imputation — the
    /// hidden-custom-team branch of the determinizer, which is exactly the
    /// blind product's opponent. `Belief::set_prior` clears the belief's
    /// `draws`/`synced` (belief.rs:443-447), so the table takes effect at the
    /// next `observe()`, whose `sync_checked` rebuilds the fallback roster and
    /// the per-slot draw plans together with it — installing before the first
    /// `observe()` is therefore both necessary and sufficient.
    ///
    /// Three refusals return `applied: false` and change nothing:
    ///
    /// - `pinOpponent` was called (open team sheet): the belief is pinned to
    ///   the opponent's true sets, so a prior must never be consulted there —
    ///   sampling would contaminate the certified open-sheet configuration;
    /// - the table yielded no usable species: not installing it keeps the
    ///   no-prior determinization *bit*-identical rather than merely
    ///   equivalent (an empty prior is inert inside the belief too, but the
    ///   guarantee is worth having structurally, at this boundary);
    /// - the first `observe()` already ran: a mid-game install would change
    ///   the information structure of a game in progress under a live search.
    ///
    /// Note the one order this report cannot describe: install-then-`pinOpponent`
    /// returns `applied: true` and is then dropped by the pin (which replaces
    /// the belief wholesale). The invariant holds — the pinned belief is
    /// prior-free either way — but the report handed back earlier has already
    /// said otherwise, so callers must not treat a stale `applied: true` as
    /// proof that a prior is live. `beliefPriorInfo()` reads the truth off the
    /// belief itself and is the surface to trust. The browser client cannot
    /// reach this order (the two calls sit in one exclusive if/else).
    #[wasm_bindgen(js_name = setBeliefPrior)]
    pub fn set_belief_prior(&mut self, json: &str) -> String {
        let prior = BeliefPrior::from_json(json);
        let mut refusals: Vec<String> = Vec::new();
        if self.pinned {
            refusals.push(
                "open-team-sheet mode (pinOpponent): the belief is pinned to the opponent's \
                 true sets, so a prior must never be consulted; table ignored"
                    .to_string(),
            );
        }
        if prior.is_empty() {
            refusals.push(
                "no usable species in the table; today's fallback imputation is unchanged"
                    .to_string(),
            );
        }
        if self.observed {
            refusals.push(
                "called after the first observe(), where it would change the information \
                 structure of a game already in progress; set the prior at team preview"
                    .to_string(),
            );
        }
        let applied = refusals.is_empty();
        let report = belief_prior_report(&prior, applied, &refusals);
        if applied {
            self.belief.set_prior(Arc::new(prior));
        }
        report
    }

    /// JSON `{installed, governed}` — whether a non-empty prior reached this
    /// game's belief, and which opponent roster slots it currently drives
    /// (`governed` in observer roster order; empty before the first
    /// `observe()`, on a pool-identified or pinned opponent, and whenever the
    /// table says nothing usable about this roster). The M18 coverage read for
    /// a live game — what the blind UI's prior chip renders.
    #[wasm_bindgen(js_name = beliefPriorInfo)]
    pub fn belief_prior_info(&self) -> String {
        serde_json::json!({
            "installed": self.belief.has_prior(),
            "governed": self.belief.prior_governed(),
        })
        .to_string()
    }
}

// ------------------------------------------------------- ProtocolSearcher

/// M15a: the imperfect-info agent driven by PLAYER-VISIBLE information only
/// — PS protocol lines + our request JSON — instead of a `Battle` object.
/// One instance per GAME (like `BlindSearcher`): feed every battle line of
/// our player stream with `pushLines`, feed each `|request|` JSON with
/// `onRequest` (which synthesizes a battle consistent with all public info,
/// hidden opponent fields imputed from the M10 belief), then pump
/// `step`/`best` exactly like the other searchers. `best` is always
/// projected onto the PS-legal choice set (incl. the Max Total Level
/// preview rule the engine does not enforce).
#[wasm_bindgen(js_name = ProtocolSearcher)]
pub struct WasmProtocolSearcher {
    dex: Rc<Dex>,
    agent: ProtocolAgent,
    /// Open-team-sheet mode (`pinOpponent`). Tracked here only so
    /// `setBeliefPrior` can refuse out loud instead of relying on the agent's
    /// internal "never onto a pinned belief" guard.
    pinned: bool,
    endgame: Option<nc2000_bot::endgame::EndgameSession>,
}

#[cfg(target_arch = "wasm32")]
#[wasm_bindgen]
extern "C" {
    #[wasm_bindgen(js_namespace = ["globalThis", "performance"], js_name = now)]
    fn endgame_now_ms() -> f64;
}

#[cfg(not(target_arch = "wasm32"))]
fn endgame_now_ms() -> f64 {
    static START: std::sync::OnceLock<std::time::Instant> = std::sync::OnceLock::new();
    START.get_or_init(std::time::Instant::now).elapsed().as_secs_f64() * 1000.0
}

/// M18 `setBeliefPrior` report: `{applied, species, meanMoveSum, skipped,
/// warnings}`. The table interpreter is total — a malformed table degrades to
/// warnings rather than an error — so the binding never throws, and this is
/// how the caller learns whether the file it handed over was understood.
/// `applied: false` means the table did NOT reach the belief; `warnings` says
/// why.
fn belief_prior_report(prior: &BeliefPrior, applied: bool, refusals: &[String]) -> String {
    let mut warnings: Vec<&str> = refusals.iter().map(String::as_str).collect();
    warnings.extend(prior.warnings().iter().map(String::as_str));
    serde_json::json!({
        "applied": applied,
        "species": prior.len(),
        "meanMoveSum": prior.mean_move_sum(),
        "skipped": prior.skipped(),
        "warnings": warnings,
    })
    .to_string()
}

#[wasm_bindgen(js_class = ProtocolSearcher)]
impl WasmProtocolSearcher {
    /// `side`: 0 = p1. `pool_json` = the opponent prior's contents
    /// (`data/belief-pool-v3/belief-pool.json` in the product). `seed` drives
    /// determinization sampling / tie-breaking. `c` defaults to the blind
    /// profile's.
    #[wasm_bindgen(constructor)]
    pub fn new(
        dex: &WasmDex,
        side: usize,
        pool_json: &str,
        seed: u32,
        c: Option<f64>,
        hp_buckets: Option<i32>,
    ) -> Result<WasmProtocolSearcher, JsError> {
        let pool: MetaPool = serde_json::from_str(pool_json).map_err(js_err)?;
        let cfg = skuct_config(c.unwrap_or_else(|| profile_c("blind")), hp_buckets);
        let agent = ProtocolAgent::new(&dex.dex, side, pool, cfg, seed as u64);
        Ok(WasmProtocolSearcher { dex: dex.dex.clone(), agent, pinned: false, endgame: None })
    }

    /// `c` defaults to the profile of the information policy the fork was
    /// recorded under.
    #[wasm_bindgen(js_name = fromFork)]
    pub fn from_fork(dex: &WasmDex, fork_json: &str, pool_json: &str, seed: u32, c: Option<f64>) -> Result<WasmProtocolSearcher, JsError> {
        let fork = ForkSpec::parse(fork_json).map_err(|e| JsError::new(&e))?;
        let pool: MetaPool = serde_json::from_str(pool_json).map_err(js_err)?;
        let recorded = if fork.info == nc2000_bot::fork::Info::Open { "open" } else { "blind" };
        let c = c.unwrap_or_else(|| profile_c(recorded));
        let agent = fork.bot_agent(&dex.dex, pool, skuct_config(c, None), seed as u64).map_err(|e| JsError::new(&e))?;
        Ok(WasmProtocolSearcher { dex: dex.dex.clone(), agent, pinned: fork.info == nc2000_bot::fork::Info::Open, endgame: None })
    }

    /// Our exact team, as submitted to PS (same JSON array shape as the
    /// `Battle` constructor). Required before the first request.
    #[wasm_bindgen(js_name = setOwnTeam)]
    pub fn set_own_team(&mut self, team_json: &str) -> Result<(), JsError> {
        let sets: Vec<PokemonSet> = serde_json::from_str(team_json).map_err(js_err)?;
        self.agent.set_own_team(sets);
        Ok(())
    }

    /// Open-team-sheet mode: pin the opponent's true sets (the M12 product
    /// policy). Without this the belief runs pool identification (the parked
    /// full-blind policy — the M15 product policy for genuinely hidden
    /// sets).
    #[wasm_bindgen(js_name = pinOpponent)]
    pub fn pin_opponent(&mut self, team_json: &str) -> Result<(), JsError> {
        let sets: Vec<PokemonSet> = serde_json::from_str(team_json).map_err(js_err)?;
        self.agent.pin_opponent(sets);
        self.pinned = true;
        // M18, belt and braces for the one unacceptable outcome: a prior
        // installed BEFORE the pin is dropped here rather than trusting the
        // agent to skip it (it does — `on_request` only installs a prior when
        // `pinned_sets` is `None` — but the certified open-sheet configuration
        // should not have to depend on reading that far).
        self.agent.set_belief_prior(Arc::new(BeliefPrior::empty()));
        Ok(())
    }

    /// M18: install the community belief prior from the table's JSON TEXT
    /// (the contents of `data/belief-prior-v0.json`, or of whatever file the
    /// caller was pointed at — wasm has no filesystem, so the caller reads).
    /// Returns the `belief_prior_report` JSON rather than throwing: the
    /// interpreter is total, so a typo degrades into `warnings` the caller can
    /// surface instead of silently playing with no prior.
    ///
    /// Governs **only** the hidden-team fallback imputation. Call before the
    /// first `onRequest` — that is where the belief is built, once per game.
    /// Three refusals return `applied: false` and change nothing:
    ///
    /// - `pinOpponent` was called: open-team-sheet play pins the opponent's
    ///   sets, so sampling would contaminate the certified open-sheet
    ///   configuration. The prior must never reach that path;
    /// - the table yielded no usable species: not installing it keeps the
    ///   no-prior determinization *bit*-identical rather than merely
    ///   equivalent (an empty prior is inert inside the belief too, but the
    ///   guarantee is worth having structurally, at this boundary);
    /// - the belief already exists, i.e. this came after the first
    ///   `onRequest`, where it could no longer take effect.
    #[wasm_bindgen(js_name = setBeliefPrior)]
    pub fn set_belief_prior(&mut self, json: &str) -> String {
        let prior = BeliefPrior::from_json(json);
        let mut refusals: Vec<String> = Vec::new();
        if self.pinned {
            refusals.push(
                "open-team-sheet mode (pinOpponent): the belief is pinned to the opponent's \
                 true sets, so a prior must never be consulted; table ignored"
                    .to_string(),
            );
        }
        if prior.is_empty() {
            refusals.push(
                "no usable species in the table; today's fallback imputation is unchanged"
                    .to_string(),
            );
        }
        if self.agent.belief().is_some() {
            refusals.push(
                "called after the first onRequest, where the belief is already built; \
                 set the prior at construction time"
                    .to_string(),
            );
        }
        let applied = refusals.is_empty();
        let report = belief_prior_report(&prior, applied, &refusals);
        if applied {
            self.agent.set_belief_prior(Arc::new(prior));
        }
        report
    }

    /// JSON `{installed, governed}` — whether a non-empty prior actually
    /// reached the live belief, and which opponent roster slots it currently
    /// drives (`governed` in `|poke|` order; empty before the first
    /// `onRequest`, on a pool-identified or pinned opponent, and whenever the
    /// table says nothing usable about this roster). The M18 coverage read for
    /// a live game.
    #[wasm_bindgen(js_name = beliefPriorInfo)]
    pub fn belief_prior_info(&self) -> String {
        let (installed, governed) = match self.agent.belief() {
            Some(b) => (b.has_prior(), b.prior_governed()),
            None => (false, Vec::new()),
        };
        serde_json::json!({ "installed": installed, "governed": governed }).to_string()
    }

    /// Feed one baked pair table for table-answered previews.
    #[wasm_bindgen(js_name = addPair)]
    pub fn add_pair(&mut self, pair_json: &str) -> Result<(), JsError> {
        self.agent.add_pair_json(pair_json).map_err(|e| JsError::new(&e))
    }

    /// Feed player-visible battle protocol lines (JSON array of strings —
    /// the lines of our player stream, `|request|` lines excluded).
    #[wasm_bindgen(js_name = pushLines)]
    pub fn push_lines(&mut self, lines_json: &str) -> Result<(), JsError> {
        let lines: Vec<String> = serde_json::from_str(lines_json).map_err(js_err)?;
        for line in &lines {
            self.agent.push_line(&self.dex, line);
        }
        Ok(())
    }

    /// Feed the request JSON at a decision point. Returns `false` for a
    /// `wait` request (nothing owed), `true` when a decision is pending
    /// (the searcher is then ready to `step`/`best`).
    #[wasm_bindgen(js_name = onRequest)]
    pub fn on_request(&mut self, request_json: &str) -> Result<bool, JsError> {
        self.endgame = None;
        self.agent.on_request(&self.dex, request_json).map_err(|e| JsError::new(&e))
    }

    /// The baked-table preview pick when one applies, else `null`.
    #[wasm_bindgen(js_name = bakedPreview)]
    pub fn baked_preview(&self) -> Option<String> {
        self.agent.baked_preview(&self.dex)
    }

    /// Pump at most `n` blind iterations. An enabled endgame session yields
    /// after one iteration; callers use the returned cumulative count.
    pub fn step(&mut self, n: u32) -> Result<u32, JsError> {
        if let Some(session) = self.endgame.as_mut() {
            return self.agent.step_with_endgame(&self.dex, n.min(1), session, &mut endgame_now_ms).map_err(|e| JsError::new(&e));
        }
        self.agent.step(&self.dex, n).map_err(|e| JsError::new(&e))
    }

    #[wasm_bindgen(js_name = beginEndgame)]
    pub fn begin_endgame(&mut self, config_json: Option<String>, milliseconds: f64) -> Result<(), JsError> {
        let started = endgame_now_ms();
        self.endgame = None;
        if let Some(json) = config_json {
            if self.agent.search().is_none() { return Err(JsError::new("beginEndgame requires a decision")); }
            let cfg = serde_json::from_str(&json).map_err(js_err)?;
            self.endgame = Some(nc2000_bot::endgame::EndgameSession::new(cfg, started, milliseconds).map_err(|e| JsError::new(&e))?);
        }
        Ok(())
    }

    #[wasm_bindgen(js_name = endgameStats)]
    pub fn endgame_stats(&self) -> String {
        self.endgame.as_ref().map_or_else(|| "null".into(), |session| serde_json::json!({
            "scope": "conditional-determinized", "stats": session.stats,
            "expired": session.expired(endgame_now_ms()),
        }).to_string())
    }

    #[wasm_bindgen(js_name = extendEndgame)]
    pub fn extend_endgame(&mut self, milliseconds: f64) -> Result<(), JsError> {
        self.endgame.as_mut().ok_or_else(|| JsError::new("extendEndgame before beginEndgame"))?
            .extend_budget(milliseconds).map_err(|e| JsError::new(&e))
    }

    pub fn iterations(&self) -> u32 {
        self.agent.iterations()
    }

    /// Current best choice as a ready-to-submit PS choice string, projected
    /// onto the request-legal set.
    pub fn best(&mut self) -> Option<String> {
        self.agent.best(&self.dex)
    }

    /// JSON `{iterations, baked, forced, actions: [...]}`.
    #[wasm_bindgen(js_name = rootPolicy)]
    pub fn root_policy(&self) -> String {
        self.agent.root_policy(&self.dex)
    }

    /// JSON `{count, fallback, candidates}` — the belief's current read.
    #[wasm_bindgen(js_name = beliefInfo)]
    pub fn belief_info(&self) -> String {
        self.agent.belief_info()
    }

    /// Full state view of the CURRENT synthesized battle (same shape as
    /// `Battle.stateView`) — the M15a gate-b surface: every public field is
    /// asserted against PS's true state by the harness.
    #[wasm_bindgen(js_name = stateView)]
    pub fn state_view(&self) -> Result<String, JsError> {
        let battle = self
            .agent
            .battle()
            .ok_or_else(|| JsError::new("stateView before onRequest"))?;
        Ok(state_view_json(battle, &self.dex).to_string())
    }

    /// Solver mode: analyze a hand-entered position instead of a protocol
    /// stream. `spec_json` is a `nc2000-position-v1` document (own sets
    /// exact, opponent public-only); it replaces the whole information set,
    /// so it may be called again every time the user edits the board.
    ///
    /// Rejections throw, naming the field that caused them: a position
    /// quietly analyzed as something other than what was typed is the one
    /// failure this feature cannot afford.
    #[wasm_bindgen(js_name = setPosition)]
    pub fn set_position(&mut self, spec_json: &str) -> Result<(), JsError> {
        self.endgame = None;
        let spec = PositionSpec::parse(spec_json).map_err(|e| JsError::new(&e))?;
        self.agent.set_position(&self.dex, &spec).map_err(|e| JsError::new(&e))
    }

    /// The current decision point as a `nc2000-position-v1` document — the
    /// inverse of `setPosition`, for saving or sharing a position. `null`
    /// before the first request or position.
    #[wasm_bindgen(js_name = positionSpec)]
    pub fn position_spec(&self) -> Option<String> {
        self.agent
            .to_position_spec(&self.dex)
            .map(|s| serde_json::to_string(&s).unwrap_or_default())
    }

    /// The full solver report for the installed position: scored actions
    /// (with the provable-no-op reasons attached), the root matrix, the
    /// damage table, and a searched line. `line_plies` 0 omits the line.
    ///
    /// Identical to `analysis::report` in the native twin
    /// (`examples/solve_position.rs`), which is what makes a number on the
    /// screen reproducible off it.
    pub fn report(&self, line_plies: usize, line_seed: u32) -> String {
        nc2000_bot::analysis::report(&self.agent, &self.dex, line_plies, line_seed as u64)
            .to_string()
    }

    /// `[legality_drift, projections]` counters (target: zeros).
    pub fn metrics(&self) -> String {
        serde_json::json!({
            "legalityDrift": self.agent.legality_drift,
            "projections": self.agent.projections,
        })
        .to_string()
    }
}

// ---------------------------------------------------------- PreviewTables

#[wasm_bindgen(js_name = PreviewTables)]
pub struct WasmTables {
    dex: Rc<Dex>,
    set: TableSet,
}

#[wasm_bindgen(js_class = PreviewTables)]
impl WasmTables {
    /// `pool_json`: the `data/meta-pool-v0/meta-pool.json` contents (JS
    /// fetches it). Builds the team-signature index; pair tables are fed in
    /// afterwards with `addPair`.
    #[wasm_bindgen(constructor)]
    pub fn new(dex: &WasmDex, pool_json: &str) -> Result<WasmTables, JsError> {
        let pool: MetaPool = serde_json::from_str(pool_json).map_err(js_err)?;
        let set = TableSet::from_pool(&dex.dex, &pool);
        Ok(WasmTables { dex: dex.dex.clone(), set })
    }

    /// Feed one baked pair table (`data/preview-tables-v0/pair-*.json`
    /// contents). Errors if the pair references teams outside the pool.
    #[wasm_bindgen(js_name = addPair)]
    pub fn add_pair(&mut self, pair_json: &str) -> Result<(), JsError> {
        self.set.add_pair_json(pair_json).map_err(|e| JsError::new(&e))
    }

    #[wasm_bindgen(js_name = pairCount)]
    pub fn pair_count(&self) -> usize {
        self.set.len()
    }

    /// Resolve the battle's matchup (both rosters matched against the pool
    /// by full-set signature). JSON `{found: false}` for unknown matchups
    /// (the caller falls back to `Searcher` preview); otherwise
    /// `{found, teamA, teamB, iAmA, value, mixed: [{slots, input, p}...],
    /// argmax: {slots, input}}` with `mixed` restricted to p > 0, sorted
    /// descending, and `value` the side-a equilibrium value.
    pub fn resolve(&self, battle: &WasmBattle, side: usize) -> String {
        let Some((tab, i_am_a)) = self.set.lookup(&battle.battle, side) else {
            return r#"{"found":false}"#.to_string();
        };
        let actions = self.set.actions();
        let (p, amax) = if i_am_a {
            (&tab.sol.p_a, tab.sol.argmax_a)
        } else {
            (&tab.sol.p_b, tab.sol.argmax_b)
        };
        let mut mixed: Vec<serde_json::Value> = p
            .iter()
            .enumerate()
            .filter(|(_, &pr)| pr > 0.0)
            .map(|(i, &pr)| {
                serde_json::json!({
                    "slots": actions[i],
                    "input": SearchChoice::Team(actions[i]).to_input(&self.dex),
                    "p": pr,
                })
            })
            .collect();
        mixed.sort_by(|a, b| b["p"].as_f64().partial_cmp(&a["p"].as_f64()).unwrap());
        serde_json::json!({
            "found": true,
            "teamA": tab.team_a,
            "teamB": tab.team_b,
            "iAmA": i_am_a,
            "value": tab.sol.value,
            "mixed": mixed,
            "argmax": {
                "slots": actions[amax],
                "input": SearchChoice::Team(actions[amax]).to_input(&self.dex),
            },
        })
        .to_string()
    }

    /// Sample a preview pick from the mixed equilibrium with a caller seed
    /// (ready-to-apply input string), or `null` for unknown matchups.
    /// Deterministic per seed — one fresh seed per preview decision.
    pub fn sample(&self, battle: &WasmBattle, side: usize, seed: u32) -> Option<String> {
        let (tab, i_am_a) = self.set.lookup(&battle.battle, side)?;
        let p = if i_am_a { &tab.sol.p_a } else { &tab.sol.p_b };
        let mut rng = SplitMix64::new(seed as u64);
        let u = rng.next_f64();
        let mut acc = 0.0;
        let mut pick = p
            .iter()
            .enumerate()
            .max_by(|a, b| a.1.partial_cmp(b.1).unwrap())
            .map(|(i, _)| i)
            .unwrap_or(0);
        for (i, &pr) in p.iter().enumerate() {
            acc += pr;
            if u < acc {
                pick = i;
                break;
            }
        }
        let triple = self.set.actions()[pick];
        Some(SearchChoice::Team(triple).to_input(&self.dex))
    }

    /// The argmax-policy pick (pure best reply to the opponent's
    /// equilibrium), or `null` for unknown matchups.
    pub fn argmax(&self, battle: &WasmBattle, side: usize) -> Option<String> {
        let (tab, i_am_a) = self.set.lookup(&battle.battle, side)?;
        let amax = if i_am_a { tab.sol.argmax_a } else { tab.sol.argmax_b };
        let triple = self.set.actions()[amax];
        Some(SearchChoice::Team(triple).to_input(&self.dex))
    }
}

// ------------------------------------------------------------ view builders

fn choice_json(battle: &Battle, dex: &Dex, side: usize, c: SearchChoice) -> serde_json::Value {
    let input = c.to_input(dex);
    match c {
        SearchChoice::Move(id) => {
            let ms = dex.move_static(id);
            let (pp, maxpp) = battle
                .active_id(side)
                .and_then(|aid| {
                    battle
                        .poke(aid)
                        .move_slots
                        .iter()
                        .find(|s| s.id == id)
                        .map(|s| (s.pp, s.maxpp))
                })
                .unwrap_or((-1, -1));
            let (move_type, category, base_power) = battle.active_id(side)
                .filter(|_| dex.moves.key(id) == "hiddenpower")
                .map(|aid| {
                    let p = battle.poke(aid);
                    let special = matches!(dex.type_name(p.hp_type),
                        "Fire" | "Water" | "Grass" | "Ice" | "Electric" | "Dark" | "Psychic" | "Dragon");
                    (p.hp_type, if special { Category::Special } else { Category::Physical }, p.hp_power)
                })
                .unwrap_or((ms.move_type, ms.category, ms.base_power));
            serde_json::json!({
                "kind": "move",
                "input": input,
                "id": dex.moves.key(id),
                "name": ms.name,
                "type": dex.type_name(move_type),
                "category": category_str(category),
                "basePower": base_power,
                "pp": pp,
                "maxpp": maxpp,
                "target": ms.target,
            })
        }
        SearchChoice::Switch(pos) => {
            let s = &battle.sides[side];
            let p = &s.roster[s.party[(pos - 1) as usize] as usize];
            serde_json::json!({
                "kind": "switch",
                "input": input,
                "pos": pos,
                "species": dex.species.get(p.species).name,
                "name": p.name.as_str(),
                "level": p.level,
                "hp": p.hp.max(0),
                "maxhp": p.maxhp,
                "status": status_str(p.status),
            })
        }
        SearchChoice::Team(slots) => serde_json::json!({
            "kind": "team",
            "input": input,
            "slots": slots,
        }),
        SearchChoice::Pass => serde_json::json!({ "kind": "pass", "input": input }),
    }
}

fn category_str(c: Category) -> &'static str {
    match c {
        Category::Physical => "Physical",
        Category::Special => "Special",
        Category::Status => "Status",
    }
}

fn status_str(s: Status) -> &'static str {
    match s {
        Status::None => "",
        other => other.as_str(),
    }
}

fn request_str(r: Option<RequestKind>) -> &'static str {
    match r {
        Some(RequestKind::TeamPreview) => "teampreview",
        Some(RequestKind::Move) => "move",
        Some(RequestKind::Switch) => "switch",
        Some(RequestKind::Wait) | None => "",
    }
}

fn poke_json(dex: &Dex, p: &Pokemon) -> serde_json::Value {
    let mut boosts = serde_json::Map::new();
    for (&b, name) in p.boosts.iter().zip(BOOST_NAMES) {
        boosts.insert(name.to_string(), serde_json::json!(b));
    }
    let moves: Vec<serde_json::Value> = p
        .move_slots
        .iter()
        .map(|s| {
            serde_json::json!({
                "id": dex.moves.key(s.id),
                "name": dex.move_static(s.id).name,
                "pp": s.pp,
                "maxpp": s.maxpp,
                "disabled": s.disabled,
            })
        })
        .collect();
    let types: Vec<&str> = p.types.iter().map(|t| dex.type_name(t)).collect();
    let volatiles: Vec<&str> =
        p.volatiles.iter().map(|(id, _)| dex.conds_key(*id)).collect();
    serde_json::json!({
        "species": dex.species.get(p.species).name,
        "name": p.name.as_str(),
        "level": p.level,
        "gender": p.gender.as_str(),
        "hp": p.hp.max(0),
        "maxhp": p.maxhp,
        "fainted": p.fainted,
        "status": status_str(p.status),
        "boosts": boosts,
        "moves": moves,
        "item": p.item.map(|it| dex.items.get(it).name.clone()),
        "types": types,
        "volatiles": volatiles,
        "trapped": p.trapped,
    })
}

fn state_view_json(battle: &Battle, dex: &Dex) -> serde_json::Value {
    let sides: Vec<serde_json::Value> = (0..2)
        .map(|n| {
            let side = &battle.sides[n];
            // party in display order (preview: 6 mons; battle: the picked 3)
            let party: Vec<serde_json::Value> = side
                .party
                .iter()
                .map(|&slot| poke_json(dex, &side.roster[slot as usize]))
                .collect();
            // display index of the active mon, if any
            let active = side
                .active
                .and_then(|slot| side.party.iter().position(|&x| x == slot));
            let conditions: Vec<&str> =
                side.side_conditions.iter().map(|(id, _)| dex.conds_key(*id)).collect();
            serde_json::json!({
                "name": side.name,
                "active": active,
                "party": party,
                "pokemonLeft": side.pokemon_left,
                "sideConditions": conditions,
                "request": request_str(side.request_state()),
            })
        })
        .collect();
    let field = serde_json::json!({
        "weather": battle.field.weather.map(|w| dex.conds_key(w)),
        "pseudoWeather": battle
            .field
            .pseudo_weather
            .iter()
            .map(|(id, _)| dex.conds_key(*id))
            .collect::<Vec<_>>(),
    });
    serde_json::json!({
        "turn": battle.turn,
        "sides": sides,
        "field": field,
        "outcome": battle.outcome().map(|o| match o {
            Outcome::P1Win => "p1",
            Outcome::P2Win => "p2",
            Outcome::Tie => "tie",
        }),
    })
}

// ------------------------------------------------------------------ misc

/// Validates a `nc2000-fork-v1` document and returns what a player needs:
/// `{label, info, turn, botSide, arms: [{input, label}]}`. Arm inputs come
/// back in the form `Battle.applyChoice` takes.
#[wasm_bindgen(js_name = forkInfo)]
pub fn fork_info(dex: &WasmDex, fork_json: &str) -> Result<String, JsError> {
    let fork = ForkSpec::parse(fork_json).map_err(|e| JsError::new(&e))?;
    let choices = fork.check(&dex.dex).map_err(|e| JsError::new(&e))?;
    let arms: Vec<serde_json::Value> = fork
        .arms
        .iter()
        .zip(&choices)
        .map(|(arm, c)| serde_json::json!({"input": c.to_input(&dex.dex), "label": arm.label}))
        .collect();
    Ok(serde_json::json!({
        "label": fork.label,
        "info": match fork.info { Info::Blind => "blind", Info::Open => "open" },
        "turn": fork.position.turn,
        "botSide": fork.bot_side(),
        "arms": arms,
        "opponentView": fork.opponent_position.is_some() || fork.exact_replay.is_some(),
    })
    .to_string())
}

/// Bot-vs-bot trials of a fork, the same `Arena` the native
/// `fork_counterfactual` runs: equal seeds and settings give the same trials.
#[wasm_bindgen(js_name = ForkArena)]
pub struct WasmForkArena {
    dex: Rc<Dex>,
    fork: ForkSpec,
    pool: MetaPool,
    arena: Arena,
}

#[wasm_bindgen(js_class = ForkArena)]
impl WasmForkArena {
    /// `arena_json`: `{bot, foe, iters, foe_iters, c, seed, max_steps}` with
    /// policies `"protocol"` / `"skuct"`.
    #[wasm_bindgen(constructor)]
    pub fn new(
        dex: &WasmDex,
        fork_json: &str,
        pool_json: &str,
        arena_json: &str,
    ) -> Result<WasmForkArena, JsError> {
        let fork = ForkSpec::parse(fork_json).map_err(|e| JsError::new(&e))?;
        fork.check(&dex.dex).map_err(|e| JsError::new(&e))?;
        let pool: MetaPool = serde_json::from_str(pool_json).map_err(js_err)?;
        let arena: Arena = serde_json::from_str(arena_json).map_err(js_err)?;
        if arena.iters == 0 || arena.foe_iters == 0 {
            return Err(JsError::new("iterations must be positive"));
        }
        if arena.foe == Policy::Protocol && fork.opponent_position.is_none() && fork.exact_replay.is_none() {
            return Err(JsError::new("this fork has no opponent_position for a protocol opponent"));
        }
        Ok(WasmForkArena { dex: dex.dex.clone(), fork, pool, arena })
    }

    /// Arm `arm` of `trial` as one JSON row (the native rows minus `elapsed_ms`).
    pub fn play(&self, trial: u32, arm: u32) -> Result<String, JsError> {
        self.arena
            .play(&self.dex, &self.fork, &self.pool, trial as usize, arm as usize)
            .map(|row| row.to_string())
            .map_err(|e| JsError::new(&e))
    }
}

#[wasm_bindgen(js_name = Kifu)]
pub struct WasmKifu {
    dex: Rc<Dex>,
    replay: Replay,
    code: String,
}

#[wasm_bindgen(js_class = Kifu)]
impl WasmKifu {
    #[wasm_bindgen(constructor)]
    pub fn new(dex: &WasmDex, code: &str) -> Result<WasmKifu, JsError> {
        let replay = Replay::decode(&dex.dex, code).map_err(|e| JsError::new(&e))?;
        Ok(Self { dex: dex.dex.clone(), replay, code: code.into() })
    }

    pub fn scenes(&self) -> Result<String, JsError> {
        let mut b = self.replay.initial(&self.dex).map_err(|e| JsError::new(&e))?;
        let mut scenes = Vec::new();
        for (round, picks) in self.replay.rounds.iter().enumerate() {
            if b.turn > 0 {
                if let Some(pick) = picks[self.replay.bot_side] {
                    let active: Vec<_> = (0..2).map(|s| b.active_id(s).map(|id| self.dex.species.get(b.poke(id).species).name.clone())).collect();
                    scenes.push(serde_json::json!({ "round": round, "turn": b.turn, "active": active,
                        "played": choice_json(&b, &self.dex, self.replay.bot_side, pick) }));
                }
            }
            self.replay.apply(&self.dex, &mut b, round).map_err(|e| JsError::new(&e))?;
        }
        Ok(serde_json::json!({ "scenes": scenes, "turns": b.turn.min(1000), "outcome": b.outcome().map(|o| format!("{o:?}")),
            "botSide": self.replay.bot_side, "info": if self.replay.open { "open" } else { "blind" } }).to_string())
    }

    pub fn scene(&self, round: usize) -> Result<String, JsError> {
        let pick = self.replay.rounds.get(round).and_then(|p| p[self.replay.bot_side]).ok_or_else(|| JsError::new("no bot action"))?;
        let mut b = self.replay.at(&self.dex, round).map_err(|e| JsError::new(&e))?;
        let legal = b.legal_choices(&self.dex, self.replay.bot_side);
        let choices: Vec<_> = legal.iter().map(|&c| choice_json(&b, &self.dex, self.replay.bot_side, c)).collect();
        Ok(serde_json::json!({ "view": state_view_json(&b, &self.dex), "choices": choices,
            "played": choice_json(&b, &self.dex, self.replay.bot_side, pick), "log": b.log }).to_string())
    }

    pub fn fork(&self, round: usize, alternative: &str, pool_json: &str) -> Result<String, JsError> {
        let pool: MetaPool = serde_json::from_str(pool_json).map_err(js_err)?;
        let fork = ForkSpec::from_replay(&self.dex, &self.code, round, alternative, &pool).map_err(|e| JsError::new(&e))?;
        serde_json::to_string(&fork).map_err(js_err)
    }
}

/// Derive a PS-format battle seed from a small integer (convenience for
/// demos/tests; any "a,b,c,d" 16-bit-limb string works directly).
#[wasm_bindgen(js_name = deriveBattleSeed)]
pub fn derive_battle_seed(seed: u32) -> String {
    SplitMix64::new(seed as u64).battle_seed()
}

/// M18: interpret a belief-prior table WITHOUT installing it anywhere — the
/// start screen wants to tell the user what their file says long before a
/// `BlindSearcher` for the game exists. Same report shape as
/// `BlindSearcher.setBeliefPrior`, where `applied` means "this table would
/// apply if installed": the per-searcher refusals (pinned opponent, already
/// observed) are not knowable from here and are therefore not claimed, so a
/// probe of a good table on an open-sheet game still reports `true`.
#[wasm_bindgen(js_name = probeBeliefPrior)]
pub fn probe_belief_prior(json: &str) -> String {
    let prior = BeliefPrior::from_json(json);
    let applied = !prior.is_empty();
    belief_prior_report(&prior, applied, &[])
}

// ------------------------------------------------------------------ tests

#[cfg(test)]
mod tests {
    use super::*;

    fn fixture_teams() -> (String, String) {
        let path = conformance::fixture::repo_root()
            .join("fixtures/corpus-v1/full/battle-001.json");
        let text = std::fs::read_to_string(&path).unwrap();
        let v: serde_json::Value = serde_json::from_str(&text).unwrap();
        (v["p1team"].to_string(), v["p2team"].to_string())
    }

    #[test]
    fn hidden_power_choice_uses_the_active_pokemon_type_category_and_power() {
        let dex = conformance::load_dex();
        for (name, ivs, expected_type, expected_category, expected_power) in [
            ("Hidden Power Ice", [30, 6, 2, 30, 30, 2], "Ice", "Special", 35),
            ("Hidden Power Flying", [14, 24, 26, 30, 30, 30], "Flying", "Physical", 70),
        ] {
            let set: PokemonSet = serde_json::from_value(serde_json::json!({
                "name":"Zapdos", "species":"Zapdos", "level":50, "moves":[name],
                "ivs":{"hp":ivs[0], "atk":ivs[1], "def":ivs[2], "spa":ivs[3], "spd":ivs[4], "spe":ivs[5]}
            })).unwrap();
            let mut battle = Battle::from_fixture(&dex, "1,2,3,4", &[set.clone()], &[set]).unwrap();
            let choices = [0,1].map(|side| Some(battle.legal_choices(&dex,side)[0]));
            battle.apply_choices(&dex, choices).unwrap();
            let choice = battle.legal_choices(&dex,0)[0];
            let value = choice_json(&battle,&dex,0,choice);
            assert_eq!(value["input"], "move hiddenpower");
            assert_eq!(value["name"], "Hidden Power");
            assert_eq!(value["type"], expected_type);
            assert_eq!(value["category"], expected_category);
            assert_eq!(value["basePower"], expected_power);
            assert_eq!(value["pp"], value["maxpp"]);
        }
    }

    #[test]
    fn embedded_dex_loads() {
        let _ = WasmDex::new().map_err(|_| "dex").unwrap();
    }

    /// M14a: the embedded-learnset validator accepts fixture teams verbatim
    /// and flags an injected illegal move; canonicalize round-trips into the
    /// Battle constructor.
    #[test]
    fn validator_flow() {
        let dex = WasmDex::new().map_err(|_| "dex").unwrap();
        let v = WasmValidator::new(&dex).map_err(|_| "validator").unwrap();
        let (p1, p2) = fixture_teams();
        for team in [&p1, &p2] {
            let r: serde_json::Value =
                serde_json::from_str(&v.validate_team(team)).unwrap();
            assert_eq!(r["ok"], true, "{r}");
        }
        // corrupt: give the first mon a move outside its learnset
        let mut t: serde_json::Value = serde_json::from_str(&p1).unwrap();
        t[0]["moves"][0] = serde_json::json!("Spikes");
        let r: serde_json::Value =
            serde_json::from_str(&v.validate_team(&t.to_string())).unwrap();
        assert_eq!(r["ok"], false, "{r}");
        assert!(r["findings"]
            .as_array()
            .unwrap()
            .iter()
            .any(|f| f["code"] == "move-illegal"));
        // canonicalize a sloppy but fixable team and construct a battle
        let mut t: serde_json::Value = serde_json::from_str(&p1).unwrap();
        t[0]["ability"] = serde_json::json!("");
        t[0]["gender"] = serde_json::Value::Null;
        let c: serde_json::Value =
            serde_json::from_str(&v.canonicalize_team(&t.to_string())).unwrap();
        assert_eq!(c["ok"], true, "{c}");
        let fixed = c["team"].to_string();
        let _ = WasmBattle::new(&dex, &fixed, &p2, "1,2,3,4")
            .map_err(|_| "battle from canonicalized team")
            .unwrap();
    }

    #[test]
    fn battle_runs_and_searcher_picks_legal() {
        let dex = WasmDex::new().map_err(|_| "dex").unwrap();
        let (p1, p2) = fixture_teams();
        let mut b = WasmBattle::new(&dex, &p1, &p2, "1,2,3,4")
            .map_err(|_| "battle")
            .unwrap();
        // preview log exists
        let log0: Vec<String> = serde_json::from_str(&b.take_new_log()).unwrap();
        assert!(!log0.is_empty());
        // play a few decisions with the stepped searcher
        for _ in 0..6 {
            if b.outcome().is_some() {
                break;
            }
            let needs: [bool; 2] = serde_json::from_str(&b.needs_choice()).unwrap();
            let mut picks: Vec<(usize, String)> = Vec::new();
            for side in 0..2 {
                if !needs[side] {
                    continue;
                }
                let legal: Vec<serde_json::Value> =
                    serde_json::from_str(&b.legal_choices(side)).unwrap();
                assert!(!legal.is_empty());
                let mut s = WasmSearcher::new(&b, side, 7 + side as u32, None, None);
                s.step(60);
                let best = s.best().unwrap();
                assert!(
                    legal.iter().any(|c| c["input"] == best.as_str()),
                    "searcher best {best} not in legal set"
                );
                picks.push((side, best));
            }
            for (side, input) in picks {
                b.apply_choice(side, &input).map_err(|_| "apply").unwrap();
            }
        }
        // state view parses and has both sides
        let view: serde_json::Value = serde_json::from_str(&b.state_view()).unwrap();
        assert_eq!(view["sides"].as_array().unwrap().len(), 2);
    }

    #[test]
    fn blind_searcher_flow() {
        let root = conformance::fixture::repo_root();
        let pool_json =
            std::fs::read_to_string(root.join("data/meta-pool-v0/meta-pool.json")).unwrap();
        let pool: serde_json::Value = serde_json::from_str(&pool_json).unwrap();
        let team = |i: usize| pool["teams"][i]["sets"].to_string();

        let dex = WasmDex::new().map_err(|_| "dex").unwrap();
        let mut b = WasmBattle::new(&dex, &team(0), &team(1), "1,2,3,4")
            .map_err(|_| "battle")
            .unwrap();
        let mut bs = WasmBlindSearcher::new(&b, 1, &pool_json, 7, None, None)
            .map_err(|_| "blind searcher")
            .unwrap();
        let pair_json = std::fs::read_to_string(
            root.join("fixtures/preview-tables-test/pair-00-01.json"),
        )
        .unwrap();
        bs.add_pair(&pair_json).map_err(|_| "pair").unwrap();

        // preview: the opponent (side 0 = pool team 0) identifies publicly
        // and the pair is baked -> table pick, no stepping needed
        bs.observe(&b).unwrap();
        let info: serde_json::Value = serde_json::from_str(&bs.belief_info()).unwrap();
        assert_eq!(info["count"], 1);
        assert_eq!(info["fallback"], false);
        assert_eq!(info["candidates"][0], pool["teams"][0]["id"]);
        let baked = bs.baked_preview().expect("baked preview pick");
        assert_eq!(bs.best().as_deref(), Some(baked.as_str()));
        let legal: Vec<serde_json::Value> =
            serde_json::from_str(&b.legal_choices(1)).unwrap();
        assert!(legal.iter().any(|c| c["input"] == baked.as_str()));
        let pol: serde_json::Value = serde_json::from_str(&bs.root_policy()).unwrap();
        assert_eq!(pol["baked"], true);

        // into battle: stepped blind search returns a legal pick
        // (team 0 is 52/52/52/51/51/51 — slots 1,2,4 sum 155 = Max Total Level)
        b.apply_choice(0, "team 1, 2, 4").map_err(|_| "apply").unwrap();
        b.apply_choice(1, &baked).map_err(|_| "apply").unwrap();
        bs.observe(&b).unwrap();
        assert!(bs.baked_preview().is_none());
        let done = bs.step(40).map_err(|_| "step").unwrap();
        assert_eq!(done, 40);
        let best = bs.best().expect("in-battle best");
        let legal: Vec<serde_json::Value> =
            serde_json::from_str(&b.legal_choices(1)).unwrap();
        assert!(legal.iter().any(|c| c["input"] == best.as_str()));

        // fallback belief: an off-pool opponent flips is_fallback and the
        // search still plays
        let (p1, _) = fixture_teams();
        let mut fb = WasmBattle::new(&dex, &p1, &team(1), "1,2,3,4")
            .map_err(|_| "battle")
            .unwrap();
        let mut bfs = WasmBlindSearcher::new(&fb, 1, &pool_json, 9, None, None)
            .map_err(|_| "blind searcher")
            .unwrap();
        bfs.observe(&fb).unwrap();
        let info: serde_json::Value = serde_json::from_str(&bfs.belief_info()).unwrap();
        assert_eq!(info["fallback"], true);
        assert_eq!(info["count"], 0);
        assert!(bfs.baked_preview().is_none());
        bfs.step(30).map_err(|_| "step").unwrap();
        let best = bfs.best().expect("fallback best");
        let legal: Vec<serde_json::Value> =
            serde_json::from_str(&fb.legal_choices(1)).unwrap();
        assert!(legal.iter().any(|c| c["input"] == best.as_str()));
    }

    /// M12 open-team-sheet mode: `pinOpponent` pins the belief to the
    /// opponent's true sets (pool or custom) and preview resolves by
    /// direct signature lookup.
    #[test]
    fn pinned_open_sheet_flow() {
        let root = conformance::fixture::repo_root();
        let pool_json =
            std::fs::read_to_string(root.join("data/meta-pool-v0/meta-pool.json")).unwrap();
        let pool: serde_json::Value = serde_json::from_str(&pool_json).unwrap();
        let team = |i: usize| pool["teams"][i]["sets"].to_string();
        let dex = WasmDex::new().map_err(|_| "dex").unwrap();

        // pool opponent + baked pair: preview answers from the table
        let mut b = WasmBattle::new(&dex, &team(0), &team(1), "1,2,3,4")
            .map_err(|_| "battle")
            .unwrap();
        let mut bs = WasmBlindSearcher::new(&b, 1, &pool_json, 7, None, None)
            .map_err(|_| "blind searcher")
            .unwrap();
        bs.pin_opponent(&team(0)).map_err(|_| "pin").unwrap();
        let pair_json = std::fs::read_to_string(
            root.join("fixtures/preview-tables-test/pair-00-01.json"),
        )
        .unwrap();
        bs.add_pair(&pair_json).map_err(|_| "pair").unwrap();
        bs.observe(&b).unwrap();
        let info: serde_json::Value = serde_json::from_str(&bs.belief_info()).unwrap();
        assert_eq!(info["count"], 1);
        assert_eq!(info["fallback"], false);
        let baked = bs.baked_preview().expect("open-sheet baked preview pick");
        let legal: Vec<serde_json::Value> =
            serde_json::from_str(&b.legal_choices(1)).unwrap();
        assert!(legal.iter().any(|c| c["input"] == baked.as_str()));

        // into battle: the pinned blind search returns a legal pick
        // (team 0 is 52/52/52/51/51/51 — slots 1,2,4 sum 155 = Max Total Level)
        b.apply_choice(0, "team 1, 2, 4").map_err(|_| "apply").unwrap();
        b.apply_choice(1, &baked).map_err(|_| "apply").unwrap();
        bs.observe(&b).unwrap();
        assert!(bs.baked_preview().is_none());
        bs.step(40).map_err(|_| "step").unwrap();
        let best = bs.best().expect("in-battle best");
        let legal: Vec<serde_json::Value> =
            serde_json::from_str(&b.legal_choices(1)).unwrap();
        assert!(legal.iter().any(|c| c["input"] == best.as_str()));

        // custom (off-pool) opponent pinned: a REAL singleton belief —
        // never fallback — with live-search preview (no table for the
        // matchup)
        let (p1, _) = fixture_teams();
        let mut fb = WasmBattle::new(&dex, &p1, &team(1), "1,2,3,4")
            .map_err(|_| "battle")
            .unwrap();
        let mut bfs = WasmBlindSearcher::new(&fb, 1, &pool_json, 9, None, None)
            .map_err(|_| "blind searcher")
            .unwrap();
        bfs.pin_opponent(&p1).map_err(|_| "pin").unwrap();
        bfs.observe(&fb).unwrap();
        let info: serde_json::Value = serde_json::from_str(&bfs.belief_info()).unwrap();
        assert_eq!(info["fallback"], false);
        assert_eq!(info["count"], 1);
        assert!(bfs.baked_preview().is_none());
        bfs.step(30).map_err(|_| "step").unwrap();
        let best = bfs.best().expect("pinned custom best");
        let legal: Vec<serde_json::Value> =
            serde_json::from_str(&fb.legal_choices(1)).unwrap();
        assert!(legal.iter().any(|c| c["input"] == best.as_str()));
    }

    // ------------------------------------------------- M18 belief prior

    /// PS `details` for a set — the only field a team-preview synthesis reads.
    fn set_details(set: &serde_json::Value) -> String {
        let species = set["species"]
            .as_str()
            .or_else(|| set["name"].as_str())
            .unwrap();
        let level = set["level"].as_i64().unwrap_or(100);
        let gender = set["gender"].as_str().unwrap_or("");
        let mut out = format!("{species}, L{level}");
        if !gender.is_empty() {
            out.push_str(&format!(", {gender}"));
        }
        out
    }

    /// The player-visible preview stream + our team-preview request, for a bot
    /// playing p2. This is the smallest real ProtocolSearcher decision point:
    /// `synthesize` returns the `from_fixture` preview state, so only `|poke|`
    /// and the request's `details` are consulted.
    fn preview_stream(p1: &serde_json::Value, p2: &serde_json::Value) -> (String, String) {
        let mut lines: Vec<String> = Vec::new();
        for (tag, team) in [("p1", p1), ("p2", p2)] {
            for set in team.as_array().unwrap() {
                lines.push(format!("|poke|{tag}|{}|item", set_details(set)));
            }
        }
        lines.push("|teampreview".to_string());
        let pokemon: Vec<serde_json::Value> = p2
            .as_array()
            .unwrap()
            .iter()
            .map(|set| {
                serde_json::json!({
                    "ident": format!("p2: {}", set["name"].as_str().unwrap()),
                    "details": set_details(set),
                    "condition": "100/100",
                    "active": false,
                    "item": set["item"].as_str().unwrap_or(""),
                })
            })
            .collect();
        let request = serde_json::json!({
            "rqid": 1,
            "teamPreview": true,
            "maxTeamSize": 3,
            "side": { "name": "bot", "id": "p2", "pokemon": pokemon },
        });
        (serde_json::to_string(&lines).unwrap(), request.to_string())
    }

    /// M18 wasm binding (`setBeliefPrior`, the ladder client's only route to a
    /// belief-prior file — wasm has no filesystem, so the table crosses as
    /// JSON text). Driven against an OFF-POOL opponent, the only belief a
    /// prior can touch, and pinning the properties the design requires:
    ///
    /// - a malformed / empty table yields warnings AND leaves the
    ///   determinization byte-identical to the no-prior default;
    /// - a real table is genuinely consumed (it governs roster slots and it
    ///   moves the search), so the binding cannot be a silent no-op;
    /// - the prior never reaches the pinned (open-team-sheet) path, in EITHER
    ///   call order — that is the one unacceptable outcome.
    #[test]
    fn belief_prior_binding() {
        let root = conformance::fixture::repo_root();
        let pool_json =
            std::fs::read_to_string(root.join("data/meta-pool-v0/meta-pool.json")).unwrap();
        let pool: serde_json::Value = serde_json::from_str(&pool_json).unwrap();
        let dex = WasmDex::new().map_err(|_| "dex").unwrap();
        // opponent = the off-pool fixture team (=> fallback belief, the only
        // one the prior governs); ours = a pool team.
        let (opp_json, _) = fixture_teams();
        let opp: serde_json::Value = serde_json::from_str(&opp_json).unwrap();
        let own = pool["teams"][1]["sets"].clone();
        let own_json = own.to_string();
        let (lines_json, request_json) = preview_stream(&opp, &own);

        /// One full decision point. `prior` = the table text to install (in
        /// `pin` order when pinning); returns `(report, rootPolicy, priorInfo)`.
        struct Run {
            report: Option<String>,
            policy: String,
            info: serde_json::Value,
        }
        let run = |prior: Option<&str>, pin: Option<&str>, pin_first: bool| -> Run {
            let mut ps = WasmProtocolSearcher::new(&dex, 1, &pool_json, 7, None, None)
                .map_err(|_| "protocol searcher")
                .unwrap();
            ps.set_own_team(&own_json).map_err(|_| "own team").unwrap();
            let mut report = None;
            let mut set_prior = |ps: &mut WasmProtocolSearcher| {
                if let Some(text) = prior {
                    report = Some(ps.set_belief_prior(text));
                }
            };
            if pin_first {
                if let Some(t) = pin {
                    ps.pin_opponent(t).map_err(|_| "pin").unwrap();
                }
                set_prior(&mut ps);
            } else {
                set_prior(&mut ps);
                if let Some(t) = pin {
                    ps.pin_opponent(t).map_err(|_| "pin").unwrap();
                }
            }
            ps.push_lines(&lines_json).map_err(|_| "lines").unwrap();
            assert!(
                ps.on_request(&request_json).map_err(|_| "request").unwrap(),
                "the team-preview request owes a choice"
            );
            assert!(ps.baked_preview().is_none(), "no pair tables were fed");
            ps.step(120).map_err(|_| "step").unwrap();
            Run {
                report,
                policy: ps.root_policy(),
                info: serde_json::from_str(&ps.belief_prior_info()).unwrap(),
            }
        };

        // ---- baseline: no prior at all (today's shipped behaviour)
        let base = run(None, None, false);
        assert_eq!(base.info["installed"], false);
        assert_eq!(base.info["governed"].as_array().unwrap().len(), 0);

        // ---- malformed / empty tables: warnings, and NOTHING changes
        for bad in [
            "{ this is not json",
            "[1, 2, 3]",
            r#""a string""#,
            r#"{"format":"nc2000-belief-prior","version":1}"#,
            r#"{"format":"nc2000-belief-prior","version":1,"species":{}}"#,
            r#"{"species":{"Snorlax":{"moves":{"Body Slam":"very likely"}}}}"#,
            "",
        ] {
            let r = run(Some(bad), None, false);
            let rep: serde_json::Value = serde_json::from_str(r.report.as_ref().unwrap()).unwrap();
            assert_eq!(rep["applied"], false, "{bad}: {rep}");
            assert_eq!(rep["species"], 0, "{bad}: {rep}");
            assert!(
                !rep["warnings"].as_array().unwrap().is_empty(),
                "{bad}: a malformed table must warn, got {rep}"
            );
            assert_eq!(r.info["installed"], false, "{bad}");
            assert_eq!(
                r.policy, base.policy,
                "{bad}: a malformed table changed the determinization"
            );
        }

        // ---- the shipped reference table: actually consumed
        let sample_text =
            std::fs::read_to_string(root.join("data/belief-prior-v0.sample.json")).unwrap();
        let sample: serde_json::Value = serde_json::from_str(&sample_text).unwrap();
        let sample_species = sample["species"].as_object().unwrap().len();
        let good = run(Some(&sample_text), None, false);
        let rep: serde_json::Value = serde_json::from_str(good.report.as_ref().unwrap()).unwrap();
        assert_eq!(rep["applied"], true, "{rep}");
        assert_eq!(rep["species"], sample_species, "{rep}");
        assert_eq!(rep["skipped"], 0, "{rep}");
        assert!(rep["warnings"].as_array().unwrap().is_empty(), "{rep}");
        assert!(rep["meanMoveSum"].as_f64().unwrap() > 0.0, "{rep}");
        assert_eq!(good.info["installed"], true);
        let governed = good.info["governed"].as_array().unwrap();
        assert_eq!(governed.len(), 6, "one flag per |poke| slot: {governed:?}");
        assert!(
            governed.iter().any(|g| g == true),
            "the sample table covers Gengar, which is on the fixture team: {governed:?}"
        );
        assert_ne!(
            good.policy, base.policy,
            "an applied prior must move the determinization"
        );

        // ---- the pinned (open-team-sheet) path: unreachable in BOTH orders
        let pinned_base = run(None, Some(&opp_json), true);
        assert_eq!(pinned_base.info["installed"], false);
        for pin_first in [true, false] {
            let r = run(Some(&sample_text), Some(&opp_json), pin_first);
            let rep: serde_json::Value = serde_json::from_str(r.report.as_ref().unwrap()).unwrap();
            if pin_first {
                assert_eq!(rep["applied"], false, "pinned first: {rep}");
                assert!(
                    rep["warnings"]
                        .as_array()
                        .unwrap()
                        .iter()
                        .any(|w| w.as_str().unwrap().contains("pinOpponent")),
                    "the refusal must name the reason: {rep}"
                );
            }
            assert_eq!(
                r.info["installed"], false,
                "pin_first={pin_first}: a prior reached the open-sheet belief"
            );
            assert_eq!(
                r.policy, pinned_base.policy,
                "pin_first={pin_first}: the open-sheet configuration changed"
            );
        }
    }

    /// M18 on the BLIND product path (`BlindSearcher.setBeliefPrior`) — the
    /// web client's only route to a belief-prior file, since wasm has no
    /// filesystem and the table crosses as JSON text. Driven against an
    /// OFF-POOL opponent, the only belief a prior can touch (a pool team
    /// identifies publicly and is imputed from its own sheet), and pinning the
    /// four properties the design requires:
    ///
    /// 1. a malformed / empty table yields warnings AND leaves the
    ///    determinization byte-identical to the no-prior default;
    /// 2. the shipped reference table is genuinely consumed — it governs
    ///    roster slots and it moves the search — so the binding cannot be a
    ///    silent no-op;
    /// 3. the prior never reaches the pinned (open-team-sheet) belief, in
    ///    EITHER call order — that is the one unacceptable outcome;
    /// 4. a table handed over after the first `observe()` is refused, so a
    ///    game in progress never changes information structure mid-flight.
    #[test]
    fn blind_belief_prior_binding() {
        let root = conformance::fixture::repo_root();
        let pool_json =
            std::fs::read_to_string(root.join("data/meta-pool-v0/meta-pool.json")).unwrap();
        let pool: serde_json::Value = serde_json::from_str(&pool_json).unwrap();
        let dex = WasmDex::new().map_err(|_| "dex").unwrap();
        // side 0 = the off-pool fixture team = the bot's opponent (=> fallback
        // belief); side 1 = the bot, on a pool team. Exactly the blind
        // product's shape: a human custom team the bot cannot identify.
        let (opp_json, _) = fixture_teams();
        let own_json = pool["teams"][1]["sets"].to_string();

        /// One team-preview decision point; `(report, rootPolicy, priorInfo)`.
        struct Run {
            report: Option<String>,
            policy: String,
            info: serde_json::Value,
        }
        // Fresh battle + searcher per run, same seeds throughout, so the
        // policies are byte-comparable. `late` moves the setBeliefPrior call
        // to AFTER the first observe(); `pin_first` orders it against
        // pinOpponent.
        let run = |prior: Option<&str>, pin: Option<&str>, pin_first: bool, late: bool| -> Run {
            let b = WasmBattle::new(&dex, &opp_json, &own_json, "1,2,3,4")
                .map_err(|_| "battle")
                .unwrap();
            let mut bs = WasmBlindSearcher::new(&b, 1, &pool_json, 7, None, None)
                .map_err(|_| "blind searcher")
                .unwrap();
            let mut report = None;
            let mut set_prior = |bs: &mut WasmBlindSearcher| {
                if let Some(text) = prior {
                    report = Some(bs.set_belief_prior(text));
                }
            };
            if pin_first {
                if let Some(t) = pin {
                    bs.pin_opponent(t).map_err(|_| "pin").unwrap();
                }
                if !late {
                    set_prior(&mut bs);
                }
            } else {
                if !late {
                    set_prior(&mut bs);
                }
                if let Some(t) = pin {
                    bs.pin_opponent(t).map_err(|_| "pin").unwrap();
                }
            }
            bs.observe(&b).unwrap();
            if late {
                set_prior(&mut bs);
            }
            assert!(bs.baked_preview().is_none(), "no pair tables were fed");
            bs.step(120).map_err(|_| "step").unwrap();
            Run {
                report,
                policy: bs.root_policy(),
                info: serde_json::from_str(&bs.belief_prior_info()).unwrap(),
            }
        };

        // ---- baseline: no prior at all (today's shipped blind behaviour)
        let base = run(None, None, false, false);
        assert_eq!(base.info["installed"], false);
        assert_eq!(base.info["governed"].as_array().unwrap().len(), 0);

        // ---- (1) malformed / empty tables: warnings, and NOTHING changes
        for bad in [
            "{ this is not json",
            "[1, 2, 3]",
            r#""a string""#,
            r#"{"format":"nc2000-belief-prior","version":1}"#,
            r#"{"format":"nc2000-belief-prior","version":1,"species":{}}"#,
            r#"{"species":{"Snorlax":{"moves":{"Body Slam":"very likely"}}}}"#,
            "",
        ] {
            let r = run(Some(bad), None, false, false);
            let rep: serde_json::Value = serde_json::from_str(r.report.as_ref().unwrap()).unwrap();
            assert_eq!(rep["applied"], false, "{bad}: {rep}");
            assert_eq!(rep["species"], 0, "{bad}: {rep}");
            assert!(
                !rep["warnings"].as_array().unwrap().is_empty(),
                "{bad}: a malformed table must warn, got {rep}"
            );
            assert_eq!(r.info["installed"], false, "{bad}");
            assert_eq!(
                r.policy, base.policy,
                "{bad}: a malformed table changed the determinization"
            );
            // The install-free probe reads the same table the same way. Its
            // `warnings` carry only the interpreter's own — the refusals are
            // per-searcher facts a free function cannot know — so the report
            // is a superset, not an equal.
            let probe: serde_json::Value =
                serde_json::from_str(&probe_belief_prior(bad)).unwrap();
            assert_eq!(probe["applied"], false, "{bad}: probe disagreed: {probe}");
            assert_eq!(probe["species"], 0, "{bad}: {probe}");
            for w in probe["warnings"].as_array().unwrap() {
                assert!(
                    rep["warnings"].as_array().unwrap().contains(w),
                    "{bad}: probe warned {w} and the binding did not: {rep}"
                );
            }
        }

        // ---- (2) the shipped reference table: actually consumed
        let sample_text =
            std::fs::read_to_string(root.join("data/belief-prior-v0.sample.json")).unwrap();
        let sample: serde_json::Value = serde_json::from_str(&sample_text).unwrap();
        let sample_species = sample["species"].as_object().unwrap().len();
        let good = run(Some(&sample_text), None, false, false);
        let rep: serde_json::Value = serde_json::from_str(good.report.as_ref().unwrap()).unwrap();
        assert_eq!(rep["applied"], true, "{rep}");
        assert_eq!(rep["species"], sample_species, "{rep}");
        assert_eq!(rep["skipped"], 0, "{rep}");
        assert!(rep["warnings"].as_array().unwrap().is_empty(), "{rep}");
        assert!(rep["meanMoveSum"].as_f64().unwrap() > 0.0, "{rep}");
        assert_eq!(good.info["installed"], true);
        let governed = good.info["governed"].as_array().unwrap();
        assert_eq!(governed.len(), 6, "one flag per opponent roster slot: {governed:?}");
        assert!(
            governed.iter().any(|g| g == true),
            "the sample table covers Gengar, which is on the fixture team: {governed:?}"
        );
        assert_ne!(
            good.policy, base.policy,
            "an applied prior must move the determinization"
        );
        // The probe agrees, without touching any searcher.
        let probe: serde_json::Value =
            serde_json::from_str(&probe_belief_prior(&sample_text)).unwrap();
        assert_eq!(probe["applied"], true, "{probe}");
        assert_eq!(probe["species"], sample_species, "{probe}");
        assert_eq!(probe["meanMoveSum"], rep["meanMoveSum"], "{probe}");

        // ---- (3) the pinned (open-team-sheet) belief: unreachable in BOTH
        // orders. Prior-then-pin still reports `applied: true` — at that
        // instant the searcher was not pinned and the answer was honest — but
        // `pinOpponent` replaces the belief wholesale, so nothing survives to
        // the game. The property that matters is asserted on the belief and on
        // the search output, not on the report.
        let pinned_base = run(None, Some(&opp_json), true, false);
        assert_eq!(pinned_base.info["installed"], false);
        assert_eq!(pinned_base.info["governed"].as_array().unwrap().len(), 0);
        for pin_first in [true, false] {
            let r = run(Some(&sample_text), Some(&opp_json), pin_first, false);
            let rep: serde_json::Value = serde_json::from_str(r.report.as_ref().unwrap()).unwrap();
            if pin_first {
                assert_eq!(rep["applied"], false, "pinned first: {rep}");
                assert!(
                    rep["warnings"]
                        .as_array()
                        .unwrap()
                        .iter()
                        .any(|w| w.as_str().unwrap().contains("pinOpponent")),
                    "the refusal must name the reason: {rep}"
                );
            }
            assert_eq!(
                r.info["installed"], false,
                "pin_first={pin_first}: a prior reached the open-sheet belief"
            );
            assert_eq!(
                r.info["governed"].as_array().unwrap().len(),
                0,
                "pin_first={pin_first}: the open-sheet belief is governed by a prior"
            );
            assert_eq!(
                r.policy, pinned_base.policy,
                "pin_first={pin_first}: the open-sheet configuration changed"
            );
        }

        // ---- (4) after the first observe(): refused, and the game in
        // progress is bit-identical to the one that never saw a table.
        let late = run(Some(&sample_text), None, false, true);
        let rep: serde_json::Value = serde_json::from_str(late.report.as_ref().unwrap()).unwrap();
        assert_eq!(rep["applied"], false, "a mid-game prior must be refused: {rep}");
        assert_eq!(rep["species"], sample_species, "the table still parsed: {rep}");
        assert!(
            rep["warnings"]
                .as_array()
                .unwrap()
                .iter()
                .any(|w| w.as_str().unwrap().contains("observe()")),
            "the refusal must name the reason: {rep}"
        );
        assert_eq!(late.info["installed"], false);
        assert_eq!(
            late.policy, base.policy,
            "a refused late prior changed the running search"
        );
    }
}
